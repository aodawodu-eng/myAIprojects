"""
generate_results_table.py

Phase 10 scope: the companion to generate_charts.py — instead of images,
this writes a single Markdown table summarizing every NFR check against
the Chapter 3.2 thresholds, in a form you can paste directly into Chapter
5's text (most Markdown renders fine pasted into Word too, or convert
with pandoc if you want a native Word table).

Reads metrics/summary.json (from summarize_metrics.py) and, if present,
metrics/severity_sweep.json (from severity_sweep.py).

Usage:
    python3 scripts/summarize_metrics.py     # generates metrics/summary.json first
    python3 scripts/generate_results_table.py

Requires only the Python standard library.
"""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SUMMARY_PATH = ROOT / "metrics" / "summary.json"
SWEEP_PATH = ROOT / "metrics" / "severity_sweep.json"
OUTPUT_PATH = ROOT / "metrics" / "results_table.md"

NFR1_AUTH_LATENCY_MS = 100
NFR2_CPU_PERCENT = 15
NFR3_AVAILABILITY_PERCENT = 99.9


def verdict(passed: bool) -> str:
    return "PASS" if passed else "FAIL"


def build_table(summary: dict, sweep: dict | None) -> str:
    lines = []
    lines.append("# LZTA Prototype — Results Summary")
    lines.append("")
    lines.append("Auto-generated from `metrics/summary.json`"
                  + (" and `metrics/severity_sweep.json`" if sweep else "")
                  + ". Regenerate after any test run with "
                  "`python3 scripts/generate_results_table.py`.")
    lines.append("")

    # --- NFR1: Authentication latency ---
    lines.append("## NFR1 — Authentication Latency (target: < 100ms)")
    lines.append("")
    auth = summary.get("latency", {}).get("auth_latency_ms", {})
    trust = summary.get("latency", {}).get("trust_latency_ms", {})
    lines.append("| Metric | n | Min (ms) | Avg (ms) | p95 (ms) | Max (ms) | Verdict |")
    lines.append("|---|---|---|---|---|---|---|")
    if auth.get("count"):
        v = verdict(auth["p95"] < NFR1_AUTH_LATENCY_MS)
        lines.append(f"| Auth latency | {auth['count']} | {auth['min']} | {auth['avg']} | {auth['p95']} | {auth['max']} | **{v}** |")
    else:
        lines.append("| Auth latency | — | — | — | — | — | no data |")
    if trust.get("count"):
        lines.append(f"| Trust-engine latency | {trust['count']} | {trust['min']} | {trust['avg']} | {trust['p95']} | {trust['max']} | (informational — not an NFR target) |")
    else:
        lines.append("| Trust-engine latency | — | — | — | — | — | no data |")
    lines.append("")

    # --- NFR2: CPU ---
    lines.append("## NFR2 — Resource Efficiency (target: CPU avg < 15%)")
    lines.append("")
    containers = summary.get("containers", {})
    lines.append("| Container | CPU avg (%) | CPU max (%) | Mem avg (MB) | Mem max (MB) | Verdict |")
    lines.append("|---|---|---|---|---|---|")
    if isinstance(containers, dict) and "note" not in containers:
        for name, stats in containers.items():
            cpu = stats.get("cpu_percent", {})
            mem = stats.get("mem_usage_mb", {})
            if cpu.get("count"):
                v = verdict(cpu["avg"] < NFR2_CPU_PERCENT)
                lines.append(f"| {name} | {cpu['avg']} | {cpu['max']} | {mem.get('avg','—')} | {mem.get('max','—')} | **{v}** |")
    else:
        lines.append(f"| _{containers.get('note','no data')}_ | | | | | |")
    lines.append("")

    # --- NFR3: Availability ---
    lines.append(f"## NFR3 — Availability (target: > {NFR3_AVAILABILITY_PERCENT}%)")
    lines.append("")
    availability = summary.get("availability", {})
    lines.append("| Target | Uptime (%) | Checks | Verdict |")
    lines.append("|---|---|---|---|")
    if isinstance(availability, dict) and "note" not in availability:
        for name, stats in availability.items():
            v = verdict(stats["uptime_percent"] >= NFR3_AVAILABILITY_PERCENT)
            lines.append(f"| {name} | {stats['uptime_percent']} | {stats['checks']} | **{v}** |")
    else:
        lines.append(f"| _{availability.get('note','no data')}_ | | | |")
    lines.append("")

    # --- Access decisions ---
    lines.append("## Access Decision Breakdown")
    lines.append("")
    decisions = summary.get("latency", {}).get("decision_counts", {})
    total = sum(decisions.values()) if decisions else 0
    lines.append("| Decision | Count | % of total |")
    lines.append("|---|---|---|")
    for d, count in decisions.items():
        pct = round(100 * count / total, 1) if total else 0
        lines.append(f"| {d} | {count} | {pct}% |")
    lines.append(f"| **Total** | **{total}** | 100% |")
    lines.append("")

    # --- Severity sweep, if present ---
    if sweep and sweep.get("results"):
        target = sweep.get("target", "unknown")
        lines.append(f"## Fault-Severity Sweep — target: `{target}`")
        lines.append("")
        all_targets = sorted({t for r in sweep["results"] for t in r["uptime"]})
        header = "| Injected loss | " + " | ".join(all_targets) + " |"
        sep = "|---|" + "---|" * len(all_targets)
        lines.append(header)
        lines.append(sep)
        for r in sweep["results"]:
            row = f"| {r['label']} | " + " | ".join(
                f"{r['uptime'].get(t, '—')}%" for t in all_targets
            ) + " |"
            lines.append(row)
        lines.append("")
        lines.append(f"_Control comparison: any target other than `{target}` staying near 100% "
                      "throughout, while the targeted service's uptime visibly drops as loss "
                      "increases, demonstrates the offline policy cache (Chapter 3, Fig. 3.5) "
                      "is doing its job — the gateway keeps functioning off cached decisions "
                      "rather than failing outright._")
        lines.append("")

    return "\n".join(lines)


def main():
    if not SUMMARY_PATH.exists():
        print(f"error: {SUMMARY_PATH} not found. Run scripts/summarize_metrics.py first.")
        return

    summary = json.loads(SUMMARY_PATH.read_text(encoding="utf-8"))
    sweep = json.loads(SWEEP_PATH.read_text(encoding="utf-8")) if SWEEP_PATH.exists() else None

    table_md = build_table(summary, sweep)
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_text(table_md, encoding="utf-8")

    print(table_md)
    print(f"\n\nWritten to {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
