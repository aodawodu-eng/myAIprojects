"""
severity_sweep.py

Phase 8 scope: automates the "one-off manual testing" you'd otherwise do
by hand with inject_fault.sh + collect_availability.py — runs a fixed
sequence of fault severities against a target service, measuring uptime
for each, and produces one table/CSV/JSON you can drop straight into
Chapter 5.

Why this exists: a single loss% test (e.g. "40% loss") can be
misleading on its own — TCP retransmission can quietly absorb moderate
packet loss within a health check's timeout window, making a 40% netem
loss rule look like it did nothing. A SEVERITY GRADIENT (0% -> 40% ->
80% -> 100%) is a much more defensible result: it shows where the
system's resilience actually breaks down, not just an up/down snapshot.

This targets ONE service at a time (trust-engine by default) so the
result is unambiguous, and reports ALL availability targets at each
level so you can see the control group (untouched services) stay near
100% throughout — that contrast is the actual evidence.

Requires:
  - inject_fault.sh must be executable and reachable at ../scripts/inject_fault.sh
    relative to this file (i.e. run from the project root or anywhere,
    it resolves its own path)
  - sudo privileges for the underlying `docker exec` calls inside
    inject_fault.sh — if you hit repeated password prompts, run
    `sudo -v` once before starting the sweep to cache credentials for
    the duration of the run

Usage:
    python3 scripts/severity_sweep.py
    python3 scripts/severity_sweep.py --target auth-service --levels 0,25,50,75,100 --duration 15
"""

import argparse
import csv
import json
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

# Reuse the exact same check logic as collect_availability.py, so a
# severity-sweep uptime% and a plain collect_availability.py uptime% are
# always directly comparable — no risk of the two scripts silently
# drifting apart in how they define "reachable".
sys.path.insert(0, str(Path(__file__).resolve().parent))
from collect_availability import poll_once  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
INJECT_FAULT_SCRIPT = ROOT / "scripts" / "inject_fault.sh"
CSV_OUTPUT = ROOT / "metrics" / "severity_sweep.csv"
JSON_OUTPUT = ROOT / "metrics" / "severity_sweep.json"

SETTLE_SECONDS = 2.0  # pause after applying/clearing a fault, before measuring


def run_inject_fault(*args: str) -> None:
    cmd = ["bash", str(INJECT_FAULT_SCRIPT), *args]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"warning: inject_fault.sh {' '.join(args)} exited {result.returncode}", file=sys.stderr)
        if result.stderr.strip():
            print(f"  stderr: {result.stderr.strip()}", file=sys.stderr)
    else:
        for line in result.stdout.strip().splitlines():
            print(f"  [inject_fault] {line}")


def apply_level(target: str, loss_percent: int) -> str:
    """Returns a human-readable label for this level."""
    if loss_percent <= 0:
        run_inject_fault("clear", target)
        return "0% (baseline, no fault)"
    if loss_percent >= 100:
        run_inject_fault("disconnect", target)
        return "100% (full disconnect)"
    run_inject_fault("loss", target, str(loss_percent))
    return f"{loss_percent}% loss"


def measure(duration: float, interval: float) -> dict:
    """Polls all availability targets for `duration` seconds, returns
    target -> uptime_percent."""
    totals = defaultdict(lambda: [0, 0])  # target -> [successes, total]
    elapsed = 0.0
    while elapsed < duration:
        for row in poll_once():
            totals[row["target"]][1] += 1
            totals[row["target"]][0] += row["reachable"]
        time.sleep(interval)
        elapsed += interval
    return {target: round(100 * s / t, 2) if t else None for target, (s, t) in totals.items()}


def main():
    parser = argparse.ArgumentParser(description="Run a fault-severity sweep and tabulate uptime per level")
    parser.add_argument("--target", type=str, default="trust-engine",
                         help="container to fault-inject (trust-engine or auth-service)")
    parser.add_argument("--levels", type=str, default="0,40,80,100",
                         help="comma-separated packet-loss percentages to test, e.g. 0,25,50,75,100")
    parser.add_argument("--duration", type=float, default=20.0,
                         help="seconds to measure availability at each level")
    parser.add_argument("--interval", type=float, default=1.0,
                         help="seconds between availability checks within each level")
    args = parser.parse_args()

    if args.target not in ("trust-engine", "auth-service"):
        print(f"warning: '{args.target}' is not trust-engine or auth-service — "
              f"inject_fault.sh needs iproute2/NET_ADMIN on the target, which is "
              f"only set up for those two containers.", file=sys.stderr)

    levels = [int(x.strip()) for x in args.levels.split(",")]

    print(f"Severity sweep: target={args.target}, levels={levels}, "
          f"{args.duration}s measured at each level ({args.interval}s intervals)")
    print("(tip: run `sudo -v` first if you'd rather not be prompted for a password mid-sweep)\n")

    results = []  # list of {"level_percent": int, "label": str, "uptime": {target: pct}}

    try:
        for level in levels:
            print(f"--- Level: {level}% packet loss on {args.target} ---")
            label = apply_level(args.target, level)
            print(f"  applied: {label}. Settling {SETTLE_SECONDS}s...")
            time.sleep(SETTLE_SECONDS)

            print(f"  measuring for {args.duration}s...")
            uptime = measure(args.duration, args.interval)
            for t, pct in uptime.items():
                print(f"    {t:<22} {pct:>7.2f}%")

            results.append({"level_percent": level, "label": label, "uptime": uptime})
            print()
    finally:
        print(f"Sweep finished (or interrupted) — clearing any active fault on {args.target}...")
        run_inject_fault("clear", args.target)

    # --- write CSV (one row per level per target) ---
    CSV_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    all_targets = sorted({t for r in results for t in r["uptime"]})
    with open(CSV_OUTPUT, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["level_percent", "label", *all_targets])
        for r in results:
            writer.writerow([r["level_percent"], r["label"], *[r["uptime"].get(t) for t in all_targets]])

    JSON_OUTPUT.write_text(json.dumps({"target": args.target, "results": results}, indent=2), encoding="utf-8")

    # --- final summary table ---
    print("=" * 70)
    print(f"SEVERITY SWEEP SUMMARY — target: {args.target}")
    print("=" * 70)
    header = f"{'level':<22}" + "".join(f"{t:>20}" for t in all_targets)
    print(header)
    for r in results:
        row = f"{r['label']:<22}" + "".join(f"{r['uptime'].get(t, float('nan')):>19.2f}%" for t in all_targets)
        print(row)
    print("=" * 70)
    print(f"\nCSV:  {CSV_OUTPUT}")
    print(f"JSON: {JSON_OUTPUT}")


if __name__ == "__main__":
    main()
