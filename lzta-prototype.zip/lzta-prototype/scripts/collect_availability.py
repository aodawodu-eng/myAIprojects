"""
collect_availability.py

Phase 7 scope: periodically checks whether each core service is reachable
and logs the result. This is your raw data for the NFR3 benchmark in
Chapter 3.2 (>99.9% availability under intermittent connectivity) — run
this normally for a baseline, then again during a Phase 8 fault-injection
run to see availability actually drop and recover.

Uses only the Python standard library — urllib for the HTTP health
checks, socket for the raw TCP broker checks. No extra packages needed.

Usage:
    python3 scripts/collect_availability.py
    python3 scripts/collect_availability.py --interval 1 --duration 120

Output: metrics/availability.csv (one row per target per interval), plus
a printed uptime % summary per target when it finishes.
"""

import argparse
import csv
import socket
import time
import urllib.error
import urllib.request
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

OUTPUT_PATH = Path(__file__).resolve().parent.parent / "metrics" / "availability.csv"
CSV_FIELDS = ["timestamp", "target", "reachable", "latency_ms", "detail"]

HTTP_TARGETS = [
    ("auth-service", "http://localhost:8000/health"),
    ("trust-engine", "http://localhost:8001/health"),
]

TCP_TARGETS = [
    ("gateway-broker-tcp", "localhost", 1883),
    ("core-broker-tcp", "localhost", 1893),
]


def check_http(url: str, timeout: float = 2.0) -> tuple[bool, float, str]:
    start = time.monotonic()
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            latency_ms = (time.monotonic() - start) * 1000
            ok = 200 <= resp.status < 300
            return ok, latency_ms, f"http_{resp.status}"
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError) as exc:
        latency_ms = (time.monotonic() - start) * 1000
        return False, latency_ms, type(exc).__name__


def check_tcp(host: str, port: int, timeout: float = 2.0) -> tuple[bool, float, str]:
    start = time.monotonic()
    try:
        with socket.create_connection((host, port), timeout=timeout):
            latency_ms = (time.monotonic() - start) * 1000
            return True, latency_ms, "tcp_connected"
    except OSError as exc:
        latency_ms = (time.monotonic() - start) * 1000
        return False, latency_ms, type(exc).__name__


def poll_once() -> list[dict]:
    now = datetime.now(timezone.utc).isoformat()
    rows = []

    for name, url in HTTP_TARGETS:
        ok, latency_ms, detail = check_http(url)
        rows.append({"timestamp": now, "target": name, "reachable": int(ok),
                      "latency_ms": round(latency_ms, 2), "detail": detail})

    for name, host, port in TCP_TARGETS:
        ok, latency_ms, detail = check_tcp(host, port)
        rows.append({"timestamp": now, "target": name, "reachable": int(ok),
                      "latency_ms": round(latency_ms, 2), "detail": detail})

    return rows


def main():
    parser = argparse.ArgumentParser(description="Poll service availability and log to CSV")
    parser.add_argument("--interval", type=float, default=2.0, help="seconds between checks (default 2)")
    parser.add_argument("--duration", type=float, default=60.0, help="total seconds to run (default 60)")
    args = parser.parse_args()

    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    write_header = not OUTPUT_PATH.exists()

    totals = defaultdict(lambda: [0, 0])  # target -> [successes, total]

    with open(OUTPUT_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        if write_header:
            writer.writeheader()

        elapsed = 0.0
        print(f"Polling every {args.interval}s for {args.duration}s -> {OUTPUT_PATH}")
        try:
            while elapsed < args.duration:
                rows = poll_once()
                for row in rows:
                    writer.writerow(row)
                    totals[row["target"]][1] += 1
                    totals[row["target"]][0] += row["reachable"]
                f.flush()
                summary = ", ".join(f"{r['target']}={'UP' if r['reachable'] else 'DOWN'}" for r in rows)
                print(f"[{elapsed:>5.0f}s] {summary}")
                time.sleep(args.interval)
                elapsed += args.interval
        except KeyboardInterrupt:
            print("\nstopped early by user")

    print(f"\ndone — see {OUTPUT_PATH}\n")
    print(f"{'target':<22} {'uptime %':>10}")
    for target, (successes, total) in totals.items():
        pct = (successes / total * 100) if total else 0.0
        print(f"{target:<22} {pct:>9.2f}%")


if __name__ == "__main__":
    main()
