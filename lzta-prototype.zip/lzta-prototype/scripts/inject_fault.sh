#!/bin/bash
#
# inject_fault.sh
#
# Phase 8 scope: applies or clears tc netem rules on a target container's
# network interface, to simulate degraded connectivity (packet loss,
# added latency) or a full disconnection, as committed to in Chapter
# 3.5.2. Requires the target container to have NET_ADMIN capability and
# iproute2 installed — already set up for auth-service and trust-engine
# in docker-compose.yml / their Dockerfiles.
#
# Usage:
#   ./scripts/inject_fault.sh delay <container> <ms> [jitter_ms]
#   ./scripts/inject_fault.sh loss <container> <percent>
#   ./scripts/inject_fault.sh disconnect <container>
#   ./scripts/inject_fault.sh clear <container>
#   ./scripts/inject_fault.sh status <container>
#
# Examples:
#   ./scripts/inject_fault.sh delay trust-engine 200 50    # 200ms +/-50ms jitter
#   ./scripts/inject_fault.sh loss auth-service 30         # 30% packet loss
#   ./scripts/inject_fault.sh disconnect trust-engine      # 100% loss = effectively down
#   ./scripts/inject_fault.sh clear trust-engine           # remove all netem rules
#
# All commands run `docker exec -u root <container> tc ...` internally.
# The interface is assumed to be eth0, which is Docker's default for a
# container attached to a single custom network (true for both
# auth-service and trust-engine, which are only on gateway_net).

set -euo pipefail

IFACE="eth0"

usage() {
    echo "Usage: $0 {delay|loss|disconnect|clear|status} <container> [args...]"
    echo "See the top of this script for examples."
    exit 1
}

require_container() {
    local container="$1"
    if ! sudo docker inspect "$container" >/dev/null 2>&1; then
        echo "error: container '$container' not found. Is docker compose up?"
        exit 1
    fi
}

case "${1:-}" in
    delay)
        [ $# -ge 3 ] || usage
        CONTAINER="$2"
        DELAY_MS="$3"
        JITTER_MS="${4:-0}"
        require_container "$CONTAINER"
        echo "Applying ${DELAY_MS}ms (+/-${JITTER_MS}ms jitter) delay to $CONTAINER..."
        sudo docker exec -u root "$CONTAINER" tc qdisc replace dev "$IFACE" root netem delay "${DELAY_MS}ms" "${JITTER_MS}ms"
        echo "done. Run '$0 status $CONTAINER' to confirm, '$0 clear $CONTAINER' to remove."
        ;;

    loss)
        [ $# -ge 3 ] || usage
        CONTAINER="$2"
        PERCENT="$3"
        require_container "$CONTAINER"
        echo "Applying ${PERCENT}% packet loss to $CONTAINER..."
        sudo docker exec -u root "$CONTAINER" tc qdisc replace dev "$IFACE" root netem loss "${PERCENT}%"
        echo "done. Run '$0 status $CONTAINER' to confirm, '$0 clear $CONTAINER' to remove."
        ;;

    disconnect)
        [ $# -ge 2 ] || usage
        CONTAINER="$2"
        require_container "$CONTAINER"
        echo "Simulating full disconnection of $CONTAINER (100% packet loss)..."
        sudo docker exec -u root "$CONTAINER" tc qdisc replace dev "$IFACE" root netem loss 100%
        echo "done. Note: unlike 'docker compose stop', the container is still running —"
        echo "this is a NETWORK-level outage, not a process-level one. Compare both in your writeup."
        ;;

    clear)
        [ $# -ge 2 ] || usage
        CONTAINER="$2"
        require_container "$CONTAINER"
        echo "Clearing netem rules from $CONTAINER..."
        sudo docker exec -u root "$CONTAINER" tc qdisc del dev "$IFACE" root 2>/dev/null || echo "(no netem rule was active)"
        echo "done."
        ;;

    status)
        [ $# -ge 2 ] || usage
        CONTAINER="$2"
        require_container "$CONTAINER"
        sudo docker exec -u root "$CONTAINER" tc qdisc show dev "$IFACE"
        ;;

    *)
        usage
        ;;
esac
