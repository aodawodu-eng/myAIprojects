"""
collect_container_metrics.py

Phase 7 scope: polls `docker stats` for every LZTA container at a fixed
interval and appends CPU% / memory usage to a CSV file. This is your raw
data for the NFR2 benchmark in Chapter 3.2 (CPU <15%, and the "constrained
hardware emulation" claim in Chapter 3.5.1).

Runs on the HOST (not inside a container) since it needs access to the
Docker daemon. Requires no extra Python packages — only the standard
library (subprocess, csv, json) is used; it shells out to the `docker`
CLI you already have installed.

Usage:
    python3 scripts/collect_container_metrics.py
    python3 scripts/collect_container_metrics.py --interval 2 --duration 120
    sudo python3 scripts/collect_container_metrics.py   # if your user
                                                          # isn't in the
                                                          # docker group

Output: metrics/container_stats.csv (one row per container per interval)
"""

import argparse
import csv
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

CONTAINERS = [
    "core-broker",
    "gateway-broker",
    "auth-service",
    "trust-engine",
    "gateway",
    "device-glucose",
    "device-pulseox",
    "device-heartrate",
]

OUTPUT_PATH = Path(__file__).resolve().parent.parent / "metrics" / "container_stats.csv"
CSV_FIELDS = ["timestamp", "container", "cpu_percent", "mem_usage_mb", "mem_limit_mb", "mem_percent", "net_io"]


def _parse_mem_field(mem_usage_str: str) -> tuple[float, float]:
    """docker stats MemUsage looks like '12.34MiB / 128MiB'. Returns
    (usage_mb, limit_mb), converting GiB if present."""

    def to_mb(value_str: str) -> float:
        value_str = value_str.strip()
        if value_str.endswith("GiB"):
            return float(value_str[:-3]) * 1024
        if value_str.endswith("MiB"):
            return float(value_str[:-3])
        if value_str.endswith("KiB"):
            return float(value_str[:-3]) / 1024
        if value_str.endswith("B"):
            return float(value_str[:-1]) / (1024 * 1024)
        return 0.0

    try:
        usage_str, limit_str = mem_usage_str.split("/")
        return round(to_mb(usage_str), 2), round(to_mb(limit_str), 2)
    except (ValueError, AttributeError):
        return 0.0, 0.0


def poll_once() -> list[dict]:
    """Runs `docker stats --no-stream` for all tracked containers and
    returns a list of row dicts. Containers that aren't currently running
    are silently skipped (docker stats would error on an unknown name)."""
    running = subprocess.run(
        ["docker", "ps", "--format", "{{.Names}}"],
        capture_output=True, text=True, check=False,
    ).stdout.split()
    targets = [c for c in CONTAINERS if c in running]

    if not targets:
        return []

    result = subprocess.run(
        ["docker", "stats", "--no-stream", "--format",
         '{{"name":"{{.Name}}","cpu":"{{.CPUPerc}}","mem":"{{.MemUsage}}","mem_pct":"{{.MemPerc}}","net":"{{.NetIO}}"}}'
         ] + targets,
        capture_output=True, text=True, check=False,
    )

    if result.returncode != 0:
        print(f"docker stats failed: {result.stderr.strip()}", file=sys.stderr)
        return []

    now = datetime.now(timezone.utc).isoformat()
    rows = []
    for line in result.stdout.strip().splitlines():
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        cpu_percent = data["cpu"].rstrip("%")
        mem_mb, mem_limit_mb = _parse_mem_field(data["mem"])
        rows.append({
            "timestamp": now,
            "container": data["name"],
            "cpu_percent": cpu_percent,
            "mem_usage_mb": mem_mb,
            "mem_limit_mb": mem_limit_mb,
            "mem_percent": data["mem_pct"].rstrip("%"),
            "net_io": data["net"],
        })
    return rows


def main():
    parser = argparse.ArgumentParser(description="Poll docker stats for LZTA containers and log to CSV")
    parser.add_argument("--interval", type=float, default=5.0, help="seconds between polls (default 5)")
    parser.add_argument("--duration", type=float, default=60.0, help="total seconds to run (default 60)")
    args = parser.parse_args()

    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    write_header = not OUTPUT_PATH.exists()

    with open(OUTPUT_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        if write_header:
            writer.writeheader()

        elapsed = 0.0
        print(f"Polling every {args.interval}s for {args.duration}s -> {OUTPUT_PATH}")
        try:
            while elapsed < args.duration:
                rows = poll_once()
                for row in rows:
                    writer.writerow(row)
                f.flush()
                if rows:
                    summary = ", ".join(f"{r['container']}={r['cpu_percent']}%/{r['mem_usage_mb']}MB" for r in rows)
                    print(f"[{elapsed:>5.0f}s] {summary}")
                else:
                    print(f"[{elapsed:>5.0f}s] no tracked containers currently running")
                time.sleep(args.interval)
                elapsed += args.interval
        except KeyboardInterrupt:
            print("\nstopped early by user")

    print(f"done — see {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
