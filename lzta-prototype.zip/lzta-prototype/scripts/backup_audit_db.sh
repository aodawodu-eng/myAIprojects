#!/bin/bash
#
# backup_audit_db.sh
#
# Operational hardening addition (beyond the original 10 phases): takes a
# consistent, safe backup of the audit database and offline policy cache,
# with automatic rotation. Run manually, or on a cron schedule for a real
# deployment (see README for a suggested crontab line).
#
# Uses SQLite's own `.backup` command rather than `cp` — this is
# important: a plain file copy can grab a half-written page mid-write if
# the gateway is actively logging a decision at that exact moment,
# producing a corrupt backup. `.backup` uses SQLite's online backup API,
# which is safe to run against a live, in-use database.
#
# Usage:
#   ./scripts/backup_audit_db.sh
#   ./scripts/backup_audit_db.sh --keep 20   # keep more/fewer backups (default 10)

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DB_PATH="$ROOT_DIR/logs/audit.db"
CACHE_PATH="$ROOT_DIR/logs/policy_cache.json"
BACKUP_DIR="$ROOT_DIR/backups"
KEEP=10

while [[ $# -gt 0 ]]; do
  case "$1" in
    --keep)
      KEEP="$2"
      shift 2
      ;;
    *)
      echo "unknown argument: $1" >&2
      exit 1
      ;;
  esac
done

mkdir -p "$BACKUP_DIR"

if [[ ! -f "$DB_PATH" ]]; then
  echo "error: $DB_PATH not found — has the gateway processed any messages yet?" >&2
  exit 1
fi

TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"
DB_BACKUP="$BACKUP_DIR/audit_${TIMESTAMP}.db"
CACHE_BACKUP="$BACKUP_DIR/policy_cache_${TIMESTAMP}.json"

echo "Backing up $DB_PATH -> $DB_BACKUP"
sqlite3 "$DB_PATH" ".backup '$DB_BACKUP'"

# Quick integrity check on the backup itself, not just the source —
# proves the backup is actually restorable, not just present on disk.
INTEGRITY="$(sqlite3 "$DB_BACKUP" "PRAGMA integrity_check;")"
if [[ "$INTEGRITY" != "ok" ]]; then
  echo "error: backup integrity check failed: $INTEGRITY" >&2
  exit 1
fi
echo "  integrity check: ok"

if [[ -f "$CACHE_PATH" ]]; then
  cp "$CACHE_PATH" "$CACHE_BACKUP"
  echo "Backed up $CACHE_PATH -> $CACHE_BACKUP"
else
  echo "note: $CACHE_PATH not found, skipping (no cached decisions yet)"
fi

# --- rotation: keep only the newest $KEEP of each type ---
rotate() {
  local pattern="$1"
  local count
  count=$(ls -1 "$BACKUP_DIR"/$pattern 2>/dev/null | wc -l)
  if [[ "$count" -gt "$KEEP" ]]; then
    ls -1t "$BACKUP_DIR"/$pattern | tail -n +$((KEEP + 1)) | xargs rm -f
    echo "  rotated: removed $((count - KEEP)) old backup(s) matching $pattern"
  fi
}
rotate "audit_*.db"
rotate "policy_cache_*.json"

TOTAL_DB_BACKUPS=$(ls -1 "$BACKUP_DIR"/audit_*.db 2>/dev/null | wc -l)
echo ""
echo "Done. $TOTAL_DB_BACKUPS audit.db backup(s) retained in $BACKUP_DIR (keeping last $KEEP)."
echo ""
echo "To restore: stop the gateway, then:"
echo "  sudo docker compose stop gateway"
echo "  cp $DB_BACKUP $DB_PATH"
echo "  sudo docker compose start gateway"
