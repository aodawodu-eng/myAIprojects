"""
subscribe_all.py

Quick manual verification tool for Phase 1: connects to the broker on
localhost and prints every message published under the healthcare/ topic
tree. Run this on your host (outside Docker) while `docker compose up`
is running.

Usage:
    python3 -m venv .venv && source .venv/bin/activate
    pip install -r devices/requirements.txt
    python3 scripts/subscribe_all.py
"""

import argparse
import json

import paho.mqtt.client as mqtt


def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print(f"connected (rc={rc}), subscribing to healthcare/#")
        client.subscribe("healthcare/#", qos=0)
    else:
        print(f"connection failed, rc={rc}")


def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode("utf-8"))
        pretty = json.dumps(payload, indent=None)
    except (ValueError, UnicodeDecodeError):
        pretty = repr(msg.payload)
    print(f"{msg.topic}  ->  {pretty}")


def main():
    parser = argparse.ArgumentParser(description="Subscribe to all healthcare/# MQTT topics")
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=1883)
    args = parser.parse_args()

    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message

    client.connect(args.host, args.port, keepalive=30)
    print("listening (Ctrl+C to stop)...")
    client.loop_forever()


if __name__ == "__main__":
    main()
