"""
alert_monitor.py

Operational hardening addition (beyond the original 10 phases): a real,
continuous alerting loop, rather than "run a script and read the
terminal output" (which is what collect_availability.py and
summarize_metrics.py give you — useful for after-the-fact analysis, not
for someone actually being paged during an incident).

Design, deliberately kept realistic rather than maximal:

  - ROLLING WINDOW, not single-check alerting. A single failed health
    check is common noise (a slow response, a GC pause) — alerting on
    every single failure would be useless spam. This tracks the uptime %
    over the last WINDOW checks per target and alerts only when that
    rolling figure drops below the threshold.
  - EDGE-TRIGGERED, not level-triggered. An alert fires once when a
    target transitions from healthy to breaching, and a resolution fires
    once when it recovers — not a repeated alert on every single check
    while still in a bad state. This is how real monitoring systems
    (Prometheus Alertmanager, PagerDuty, etc.) behave, and is the
    difference between a usable alert log and an unusable one.
  - Reuses collect_availability.poll_once() directly — the exact same
    check logic as the rest of Phase 7's monitoring, so an alert here
    and a plain availability report always agree on what "reachable"
    means.

This does NOT attempt to be a real SIEM/alerting platform (no email/SMS/
Slack integration, no on-call rotation) — that's genuinely out of scope
for a student prototype. What it demonstrates is the *mechanism*
(rolling window + edge-triggered thresholding) that any real alerting
system is built on, with an honest, working implementation of it.

Usage:
    python3 scripts/alert_monitor.py                       # runs until Ctrl+C
    python3 scripts/alert_monitor.py --duration 120          # runs for 2 minutes
    python3 scripts/alert_monitor.py --threshold 99.9 --window 20 --interval 2
    python3 scripts/alert_monitor.py --once                  # single evaluation, for testing/demo
"""

import argparse
import json
import sys
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from collect_availability import poll_once  # noqa: E402 - reuse the exact same check logic

ROOT = Path(__file__).resolve().parent.parent
ALERT_LOG = ROOT / "logs" / "alerts.log"

DEFAULT_THRESHOLD_PERCENT = 99.9  # matches NFR3
DEFAULT_WINDOW = 20
DEFAULT_INTERVAL = 2.0


def write_alert(event: dict) -> None:
    ALERT_LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(ALERT_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(event) + "\n")


def banner(text: str, char: str = "!") -> None:
    line = char * min(len(text) + 4, 78)
    print(f"\n{line}\n{char} {text}\n{line}\n")


def main():
    parser = argparse.ArgumentParser(description="Continuous rolling-window availability alerting")
    parser.add_argument("--interval", type=float, default=DEFAULT_INTERVAL, help="seconds between checks")
    parser.add_argument("--window", type=int, default=DEFAULT_WINDOW, help="number of recent checks per target to base uptime%% on")
    parser.add_argument("--threshold", type=float, default=DEFAULT_THRESHOLD_PERCENT, help="uptime%% below which a target is considered breaching (NFR3 default: 99.9)")
    parser.add_argument("--duration", type=float, default=0, help="seconds to run for (0 = run until Ctrl+C)")
    parser.add_argument("--once", action="store_true", help="run a single window's worth of checks and evaluate once, then exit (useful for a quick demo)")
    args = parser.parse_args()

    windows: dict = defaultdict(lambda: deque(maxlen=args.window))
    breaching: dict = defaultdict(bool)  # target -> currently in a breach state?

    print(f"Alert monitor started: window={args.window} checks, threshold={args.threshold}%, "
          f"interval={args.interval}s, log={ALERT_LOG}")
    if args.once:
        print(f"(--once: collecting {args.window} checks then evaluating, ~{args.window * args.interval:.0f}s)")
    print("Ctrl+C to stop.\n")

    write_alert({"event": "monitor_started", "at": datetime.now(timezone.utc).isoformat(),
                 "threshold_percent": args.threshold, "window": args.window})

    checks_done = 0
    start = time.monotonic()

    try:
        while True:
            now = datetime.now(timezone.utc).isoformat()
            for row in poll_once():
                target = row["target"]
                windows[target].append(row["reachable"])

            checks_done += 1

            for target, window in windows.items():
                if len(window) < args.window and not args.once:
                    continue  # not enough data yet to trust the rolling figure
                uptime_pct = round(100 * sum(window) / len(window), 2)
                is_breaching = uptime_pct < args.threshold

                if is_breaching and not breaching[target]:
                    breaching[target] = True
                    event = {"event": "alert_raised", "at": now, "target": target,
                              "uptime_percent": uptime_pct, "threshold_percent": args.threshold,
                              "window_size": len(window)}
                    write_alert(event)
                    banner(f"ALERT: {target} availability {uptime_pct}% "
                           f"(below {args.threshold}% NFR3 threshold, over last {len(window)} checks)")

                elif not is_breaching and breaching[target]:
                    breaching[target] = False
                    event = {"event": "alert_resolved", "at": now, "target": target,
                              "uptime_percent": uptime_pct}
                    write_alert(event)
                    print(f"[RESOLVED] {target} back to {uptime_pct}% (>= {args.threshold}%)")

            if args.once and windows and all(len(w) >= args.window for w in windows.values()):
                print("\n--once: window filled, final state:")
                for target, window in windows.items():
                    uptime_pct = round(100 * sum(window) / len(window), 2)
                    status = "BREACHING" if breaching[target] else "ok"
                    print(f"  {target:<22} {uptime_pct:>7.2f}%  [{status}]")
                break

            if args.duration and (time.monotonic() - start) >= args.duration:
                print(f"\nDuration limit ({args.duration}s) reached, stopping.")
                break

            time.sleep(args.interval)

    except KeyboardInterrupt:
        print("\nStopped by user.")

    write_alert({"event": "monitor_stopped", "at": datetime.now(timezone.utc).isoformat(), "checks_done": checks_done})
    print(f"\nAlert log: {ALERT_LOG}")


if __name__ == "__main__":
    main()
