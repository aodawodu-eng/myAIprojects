"""
summarize_metrics.py

Phase 7 scope: the report that ties everything together. Pulls
authentication/trust latency directly out of `logs/audit.db` (populated
continuously since Phase 6), combines it with whatever
`collect_container_metrics.py` and `collect_availability.py` have logged,
and checks the results against the specific benchmarks Chapter 3.2
committed to:

    NFR1 — authentication latency        < 100 ms
    NFR2 — CPU utilisation               < 15%
    NFR3 — availability                  > 99.9%

Also writes metrics/summary.json so Phase 10's chart-generation scripts
have a single, already-computed source to plot from instead of
re-deriving everything from raw CSVs each time.

Usage:
    python3 scripts/summarize_metrics.py

Run this AFTER you've had the system running for a while (so audit.db has
real data) and, ideally, after running collect_container_metrics.py and
collect_availability.py alongside it. Missing CSVs are handled gracefully
— you'll just get a note that that section has no data yet, rather than
an error.
"""

import csv
import json
import sqlite3
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
AUDIT_DB_PATH = ROOT / "logs" / "audit.db"
CONTAINER_STATS_PATH = ROOT / "metrics" / "container_stats.csv"
AVAILABILITY_PATH = ROOT / "metrics" / "availability.csv"
SUMMARY_OUTPUT_PATH = ROOT / "metrics" / "summary.json"

NFR1_AUTH_LATENCY_MS = 100
NFR2_CPU_PERCENT = 15
NFR3_AVAILABILITY_PERCENT = 99.9


def _stats(values: list[float]) -> dict:
    if not values:
        return {"count": 0}
    values_sorted = sorted(values)
    p95_index = min(int(len(values_sorted) * 0.95), len(values_sorted) - 1)
    return {
        "count": len(values),
        "min": round(min(values), 2),
        "avg": round(statistics.mean(values), 2),
        "p95": round(values_sorted[p95_index], 2),
        "max": round(max(values), 2),
    }


def summarize_latency() -> dict:
    if not AUDIT_DB_PATH.exists():
        return {"error": f"{AUDIT_DB_PATH} not found — has the gateway run yet?"}

    conn = sqlite3.connect(AUDIT_DB_PATH)
    try:
        auth_latencies = [
            row[0] for row in conn.execute(
                "SELECT auth_latency_ms FROM sessions WHERE auth_latency_ms IS NOT NULL"
            )
        ]

        trust_latencies = []
        for (context_snapshot,) in conn.execute("SELECT context_snapshot FROM trust_scores"):
            try:
                data = json.loads(context_snapshot)
                if data.get("trust_latency_ms") is not None:
                    trust_latencies.append(data["trust_latency_ms"])
            except (json.JSONDecodeError, TypeError):
                continue

        decision_counts = dict(conn.execute(
            "SELECT decision, COUNT(*) FROM access_decisions GROUP BY decision"
        ).fetchall())

        device_counts = dict(conn.execute(
            "SELECT device_id, COUNT(*) FROM access_decisions ad "
            "JOIN sessions s ON ad.session_id = s.session_id "
            "GROUP BY s.device_id"
        ).fetchall())
    finally:
        conn.close()

    return {
        "auth_latency_ms": _stats(auth_latencies),
        "trust_latency_ms": _stats(trust_latencies),
        "decision_counts": decision_counts,
        "messages_per_device": device_counts,
    }


def summarize_container_stats() -> dict:
    if not CONTAINER_STATS_PATH.exists():
        return {"note": f"{CONTAINER_STATS_PATH} not found — run collect_container_metrics.py first"}

    per_container = defaultdict(lambda: {"cpu": [], "mem_mb": []})
    with open(CONTAINER_STATS_PATH, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            try:
                per_container[row["container"]]["cpu"].append(float(row["cpu_percent"]))
                per_container[row["container"]]["mem_mb"].append(float(row["mem_usage_mb"]))
            except (ValueError, KeyError):
                continue

    result = {}
    for container, data in per_container.items():
        result[container] = {
            "cpu_percent": _stats(data["cpu"]),
            "mem_usage_mb": _stats(data["mem_mb"]),
        }
    return result


def summarize_availability() -> dict:
    if not AVAILABILITY_PATH.exists():
        return {"note": f"{AVAILABILITY_PATH} not found — run collect_availability.py first"}

    per_target = defaultdict(lambda: [0, 0])
    with open(AVAILABILITY_PATH, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            try:
                per_target[row["target"]][1] += 1
                per_target[row["target"]][0] += int(row["reachable"])
            except (ValueError, KeyError):
                continue

    result = {}
    for target, (successes, total) in per_target.items():
        pct = (successes / total * 100) if total else 0.0
        result[target] = {"uptime_percent": round(pct, 3), "checks": total}
    return result


def print_report(latency: dict, containers: dict, availability: dict) -> None:
    print("=" * 70)
    print("LZTA PROTOTYPE — METRICS SUMMARY")
    print("=" * 70)

    print("\n--- Authentication & Trust Latency (NFR1: target < 100ms) ---")
    auth = latency.get("auth_latency_ms", {})
    if auth.get("count"):
        verdict = "PASS" if auth["p95"] < NFR1_AUTH_LATENCY_MS else "FAIL"
        print(f"  auth_latency_ms   n={auth['count']:<5} avg={auth['avg']:<7} p95={auth['p95']:<7} max={auth['max']:<7} [{verdict} vs {NFR1_AUTH_LATENCY_MS}ms @ p95]")
    else:
        print("  no auth latency data in audit.db yet")

    trust = latency.get("trust_latency_ms", {})
    if trust.get("count"):
        print(f"  trust_latency_ms  n={trust['count']:<5} avg={trust['avg']:<7} p95={trust['p95']:<7} max={trust['max']:<7}")
    else:
        print("  no trust latency data yet (or gateway predates the trust_latency_ms field — rebuild + re-run)")

    print("\n--- Access Decisions ---")
    for decision, count in latency.get("decision_counts", {}).items():
        print(f"  {decision:<10} {count}")

    print("\n--- Container Resource Usage (NFR2: target CPU < 15%) ---")
    if isinstance(containers, dict) and "note" not in containers:
        for container, stats in containers.items():
            cpu = stats["cpu_percent"]
            mem = stats["mem_usage_mb"]
            if cpu.get("count"):
                verdict = "PASS" if cpu["avg"] < NFR2_CPU_PERCENT else "FAIL"
                print(f"  {container:<18} cpu avg={cpu['avg']:<6}% max={cpu['max']:<6}%  mem avg={mem['avg']:<7}MB max={mem['max']:<7}MB [{verdict} vs {NFR2_CPU_PERCENT}% avg]")
    else:
        print(f"  {containers.get('note', 'no data')}")

    print(f"\n--- Availability (NFR3: target > {NFR3_AVAILABILITY_PERCENT}%) ---")
    if isinstance(availability, dict) and "note" not in availability:
        for target, stats in availability.items():
            verdict = "PASS" if stats["uptime_percent"] >= NFR3_AVAILABILITY_PERCENT else "FAIL"
            print(f"  {target:<22} {stats['uptime_percent']:>7.3f}% ({stats['checks']} checks) [{verdict}]")
    else:
        print(f"  {availability.get('note', 'no data')}")

    print("\n" + "=" * 70)


def main():
    latency = summarize_latency()
    containers = summarize_container_stats()
    availability = summarize_availability()

    print_report(latency, containers, availability)

    SUMMARY_OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(SUMMARY_OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump({
            "latency": latency,
            "containers": containers,
            "availability": availability,
        }, f, indent=2)
    print(f"\nFull data written to {SUMMARY_OUTPUT_PATH} (Phase 10 will chart this)")


if __name__ == "__main__":
    main()
