"""
generate_charts.py

Phase 10 scope: turns the numbers already computed by
`summarize_metrics.py` (metrics/summary.json) and, if present,
`severity_sweep.py` (metrics/severity_sweep.json) into PNG charts ready
to drop straight into Chapter 5. Also reads metrics/container_stats.csv
directly (via pandas) for a genuine time-series view, since the
aggregated summary only has min/avg/p95/max, not the shape of usage over
time.

Every chart marks the relevant Chapter 3.2 threshold (NFR1/2/3) as a
reference line where applicable, so PASS/FAIL is visually obvious, not
just a number in a table.

Requires matplotlib and pandas (already named in Chapter 3.5.3):
    pip install matplotlib pandas --break-system-packages

Usage:
    python3 scripts/summarize_metrics.py     # generates metrics/summary.json first
    python3 scripts/generate_charts.py       # then chart it

Missing inputs are skipped with a printed note rather than crashing —
run whichever of Phases 6-8 you actually completed, this only charts
what's there.
"""

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # no display needed, just write files
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent
SUMMARY_PATH = ROOT / "metrics" / "summary.json"
SWEEP_PATH = ROOT / "metrics" / "severity_sweep.json"
CONTAINER_STATS_PATH = ROOT / "metrics" / "container_stats.csv"
CHARTS_DIR = ROOT / "metrics" / "charts"

NFR1_AUTH_LATENCY_MS = 100
NFR2_CPU_PERCENT = 15
NFR3_AVAILABILITY_PERCENT = 99.9

# Consistent, colourblind-reasonable palette across all charts
COLOR_PRIMARY = "#2E4A62"
COLOR_SECONDARY = "#5B8FB9"
COLOR_ALLOW = "#4C8C4A"
COLOR_DENY = "#B5453C"
COLOR_STEPUP = "#D4A83C"
COLOR_THRESHOLD = "#B5453C"


def savefig(fig, name: str) -> None:
    CHARTS_DIR.mkdir(parents=True, exist_ok=True)
    path = CHARTS_DIR / name
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  wrote {path}")


def chart_latency(summary: dict) -> None:
    latency = summary.get("latency", {})
    auth = latency.get("auth_latency_ms", {})
    trust = latency.get("trust_latency_ms", {})
    if not auth.get("count") and not trust.get("count"):
        print("  skipping latency chart — no data")
        return

    metrics_labels = ["avg", "p95", "max"]
    auth_vals = [auth.get(m, 0) for m in metrics_labels] if auth.get("count") else [0, 0, 0]
    trust_vals = [trust.get(m, 0) for m in metrics_labels] if trust.get("count") else [0, 0, 0]

    x = range(len(metrics_labels))
    width = 0.35
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar([i - width / 2 for i in x], auth_vals, width, label="Auth latency", color=COLOR_PRIMARY)
    ax.bar([i + width / 2 for i in x], trust_vals, width, label="Trust latency", color=COLOR_SECONDARY)
    ax.axhline(NFR1_AUTH_LATENCY_MS, color=COLOR_THRESHOLD, linestyle="--", linewidth=1,
               label=f"NFR1 target ({NFR1_AUTH_LATENCY_MS}ms)")
    ax.set_xticks(list(x))
    ax.set_xticklabels(metrics_labels)
    ax.set_ylabel("Latency (ms)")
    ax.set_title("Authentication & Trust-Engine Latency vs NFR1 Target")
    ax.legend()
    fig.tight_layout()
    savefig(fig, "auth_trust_latency.png")


def chart_decisions(summary: dict) -> None:
    counts = summary.get("latency", {}).get("decision_counts", {})
    if not counts:
        print("  skipping decision breakdown chart — no data")
        return

    order = [d for d in ("allow", "step_up", "deny") if d in counts]
    colors = {"allow": COLOR_ALLOW, "step_up": COLOR_STEPUP, "deny": COLOR_DENY}
    vals = [counts[d] for d in order]

    fig, ax = plt.subplots(figsize=(5, 4))
    bars = ax.bar(order, vals, color=[colors[d] for d in order])
    ax.bar_label(bars)
    ax.set_ylabel("Number of access decisions")
    ax.set_title("Access Decision Breakdown")
    fig.tight_layout()
    savefig(fig, "decision_breakdown.png")


def chart_resource_usage(summary: dict) -> None:
    containers = summary.get("containers", {})
    if not containers or "note" in containers:
        print("  skipping resource usage chart — no data")
        return

    names = list(containers.keys())
    cpu_avg = [containers[n]["cpu_percent"].get("avg", 0) for n in names]
    cpu_max = [containers[n]["cpu_percent"].get("max", 0) for n in names]

    x = range(len(names))
    width = 0.35
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.bar([i - width / 2 for i in x], cpu_avg, width, label="avg CPU%", color=COLOR_PRIMARY)
    ax.bar([i + width / 2 for i in x], cpu_max, width, label="max CPU%", color=COLOR_SECONDARY)
    ax.axhline(NFR2_CPU_PERCENT, color=COLOR_THRESHOLD, linestyle="--", linewidth=1,
               label=f"NFR2 target ({NFR2_CPU_PERCENT}%)")
    ax.set_xticks(list(x))
    ax.set_xticklabels(names, rotation=30, ha="right")
    ax.set_ylabel("CPU %")
    ax.set_title("Container CPU Usage vs NFR2 Target")
    ax.legend()
    fig.tight_layout()
    savefig(fig, "cpu_usage.png")

    mem_avg = [containers[n]["mem_usage_mb"].get("avg", 0) for n in names]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.bar(names, mem_avg, color=COLOR_PRIMARY)
    ax.set_xticks(range(len(names)))
    ax.set_xticklabels(names, rotation=30, ha="right")
    ax.set_ylabel("Memory (MB)")
    ax.set_title("Container Average Memory Usage")
    fig.tight_layout()
    savefig(fig, "memory_usage.png")


def chart_availability(summary: dict) -> None:
    availability = summary.get("availability", {})
    if not availability or "note" in availability:
        print("  skipping availability chart — no data")
        return

    names = list(availability.keys())
    vals = [availability[n]["uptime_percent"] for n in names]
    colors = [COLOR_ALLOW if v >= NFR3_AVAILABILITY_PERCENT else COLOR_DENY for v in vals]

    fig, ax = plt.subplots(figsize=(7, 4))
    bars = ax.bar(names, vals, color=colors)
    ax.bar_label(bars, fmt="%.2f%%")
    ax.axhline(NFR3_AVAILABILITY_PERCENT, color=COLOR_THRESHOLD, linestyle="--", linewidth=1,
               label=f"NFR3 target ({NFR3_AVAILABILITY_PERCENT}%)")
    ax.set_xticks(range(len(names)))
    ax.set_xticklabels(names, rotation=20, ha="right")
    ax.set_ylabel("Uptime %")
    ax.set_ylim(0, 105)
    ax.set_title("Service Availability vs NFR3 Target")
    ax.legend()
    fig.tight_layout()
    savefig(fig, "availability.png")


def chart_severity_sweep() -> None:
    if not SWEEP_PATH.exists():
        print("  skipping severity sweep chart — metrics/severity_sweep.json not found (run severity_sweep.py first)")
        return

    data = json.loads(SWEEP_PATH.read_text(encoding="utf-8"))
    results = data.get("results", [])
    if not results:
        print("  skipping severity sweep chart — empty results")
        return

    all_targets = sorted({t for r in results for t in r["uptime"]})
    levels = [r["level_percent"] for r in results]

    fig, ax = plt.subplots(figsize=(7, 4.5))
    for target in all_targets:
        values = [r["uptime"].get(target) for r in results]
        style = "o-" if target == data.get("target") else "s--"
        ax.plot(levels, values, style, label=target)

    ax.axhline(NFR3_AVAILABILITY_PERCENT, color=COLOR_THRESHOLD, linestyle=":", linewidth=1,
               label=f"NFR3 target ({NFR3_AVAILABILITY_PERCENT}%)")
    ax.set_xlabel("Injected packet loss (%)")
    ax.set_ylabel("Uptime %")
    ax.set_ylim(-5, 105)
    ax.set_title(f"Availability vs Fault Severity — target: {data.get('target')}")
    ax.legend()
    fig.tight_layout()
    savefig(fig, "severity_sweep.png")


def chart_cpu_over_time() -> None:
    """The one chart that genuinely needs the raw time series rather than
    the pre-aggregated summary — uses pandas directly on
    container_stats.csv, per Chapter 3.5.3."""
    if not CONTAINER_STATS_PATH.exists():
        print("  skipping CPU-over-time chart — metrics/container_stats.csv not found")
        return

    import pandas as pd

    df = pd.read_csv(CONTAINER_STATS_PATH, parse_dates=["timestamp"])
    if df.empty:
        print("  skipping CPU-over-time chart — container_stats.csv is empty")
        return

    fig, ax = plt.subplots(figsize=(9, 4.5))
    for container, group in df.groupby("container"):
        group = group.sort_values("timestamp")
        ax.plot(group["timestamp"], group["cpu_percent"], label=container)

    ax.axhline(NFR2_CPU_PERCENT, color=COLOR_THRESHOLD, linestyle="--", linewidth=1,
               label=f"NFR2 target ({NFR2_CPU_PERCENT}%)")
    ax.set_xlabel("Time")
    ax.set_ylabel("CPU %")
    ax.set_title("Container CPU Usage Over Time")
    ax.legend(fontsize=8, loc="upper left", bbox_to_anchor=(1.01, 1))
    fig.autofmt_xdate()
    fig.tight_layout()
    savefig(fig, "cpu_over_time.png")


def main():
    print("Generating charts...")

    if SUMMARY_PATH.exists():
        summary = json.loads(SUMMARY_PATH.read_text(encoding="utf-8"))
        chart_latency(summary)
        chart_decisions(summary)
        chart_resource_usage(summary)
        chart_availability(summary)
    else:
        print(f"  {SUMMARY_PATH} not found — run scripts/summarize_metrics.py first. "
              f"Skipping latency/decision/resource/availability charts.")

    chart_severity_sweep()
    chart_cpu_over_time()

    print(f"\nDone. Charts written to {CHARTS_DIR}/")


if __name__ == "__main__":
    main()
