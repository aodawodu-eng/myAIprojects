"""
gateway_service.py

This is the Edge Gateway described in Chapter 3 (hosting the Policy
Enforcement Point and a Local Policy Decision Point). As of Phase 4 it
does five things:

  1. INTERCEPT    — every device connects to the gateway-facing broker,
                    not the core broker.
  2. AUTHENTICATE — calls the Authentication Service to validate each
                    message's HMAC token.
  3. SCORE        — calls the Trust Scoring Engine with the auth outcome
                    and the device's short-term history, getting back a
                    score and a decision (allow / step_up / deny).
  4. FALL BACK    — if either the auth-service or the trust-engine is
                    unreachable, the gateway uses its LOCAL POLICY CACHE
                    (the last known-good decision for that device) rather
                    than failing the whole system open or closed. This is
                    the offline-resilience behaviour from Chapter 3's
                    Figure 3.5 workflow, and directly answers the
                    cloud-dependency research question from Chapter 1.
                    A device with no cached decision yet is denied — you
                    cannot fall back to a decision that has never existed.
  5. FORWARD/DENY — allow/step_up messages are forwarded upstream to the
                    core broker; deny messages are dropped. Every outcome
                    is logged with full reasoning and both service
                    latencies.

Still no topic-level access control (FR5 / micro-segmentation) — that's
Phase 5. Right now a trusted device can publish to any topic.
"""

import json
import logging
import os
import signal
import sqlite3
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import paho.mqtt.client as mqtt
import requests

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

GATEWAY_BROKER_HOST = os.environ.get("GATEWAY_BROKER_HOST", "gateway-broker")
GATEWAY_BROKER_PORT = int(os.environ.get("GATEWAY_BROKER_PORT", "1883"))

UPSTREAM_BROKER_HOST = os.environ.get("UPSTREAM_BROKER_HOST", "core-broker")
UPSTREAM_BROKER_PORT = int(os.environ.get("UPSTREAM_BROKER_PORT", "1883"))

AUTH_SERVICE_URL = os.environ.get("AUTH_SERVICE_URL", "http://auth-service:8000/validate")
AUTH_TIMEOUT_SECONDS = float(os.environ.get("AUTH_TIMEOUT_SECONDS", "3"))

# Shared, connection-pooling HTTP session for calls to auth-service and
# trust-engine. Found via real measurement (not assumed upfront) that a
# bare requests.post() per call — the original implementation — opens a
# brand-new TCP connection for every single request, adding avoidable
# per-request overhead (and, under host contention, exposing every
# request to potential connection-setup delays rather than reusing a
# connection that's already established). A single Session with a
# reasonably sized pool keeps sockets to auth-service/trust-engine open
# and reused across requests. This is separate from, and additive to,
# the trust-engine write-debounce fix — the two address different parts
# of the same measured latency problem, not the same one twice.
_http_session = requests.Session()
_http_session.mount(
    "http://",
    requests.adapters.HTTPAdapter(pool_connections=4, pool_maxsize=10, max_retries=0),
)

TRUST_ENGINE_URL = os.environ.get("TRUST_ENGINE_URL", "http://trust-engine:8000/trust-score")
TRUST_TIMEOUT_SECONDS = float(os.environ.get("TRUST_TIMEOUT_SECONDS", "3"))

POLICY_CACHE_PATH = Path(os.environ.get("POLICY_CACHE_PATH", "/app/logs/policy_cache.json"))

SUBSCRIBE_TOPIC = os.environ.get("SUBSCRIBE_TOPIC", "healthcare/#")
LOG_FILE = Path(os.environ.get("GATEWAY_LOG_FILE", "/app/logs/gateway.log"))
AUDIT_DB_PATH = Path(os.environ.get("AUDIT_DB_PATH", "/app/logs/audit.db"))

logging.basicConfig(
    level=logging.INFO,
    format="[gateway] %(asctime)s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("gateway")

_running = True


def _handle_shutdown(signum, frame):
    global _running
    log.info("shutdown signal received")
    _running = False


signal.signal(signal.SIGTERM, _handle_shutdown)
signal.signal(signal.SIGINT, _handle_shutdown)


# ---------------------------------------------------------------------------
# Audit trail (JSON Lines file) — a placeholder for the SQLite audit_log
# table that arrives in Phase 6. Kept dead simple on purpose: one JSON
# object per line, append-only, human-readable with `cat` or `tail -f`.
# ---------------------------------------------------------------------------

LOG_FILE.parent.mkdir(parents=True, exist_ok=True)


def record_event(event: dict) -> None:
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(event) + "\n")


# ---------------------------------------------------------------------------
# Audit database — SQLite schema matching Chapter 3's ER diagram (Figure
# 3.4): devices, sessions, trust_scores, access_decisions, audit_log.
# The gateway is the single writer, since it's the one component that
# already has the full picture (auth outcome, trust score, topic
# decision) for every message in one place — no extra network hop needed
# just to persist an audit record.
#
# The JSON-lines file above is kept alongside this for quick human
# tailing (`tail -f logs/gateway.log`); this database is the queryable,
# structured version used for the compliance mapping (Objective vii) and
# for Chapter 5's results analysis.
# ---------------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS devices (
    device_id       TEXT PRIMARY KEY,
    device_type     TEXT,
    first_seen      TEXT,
    status          TEXT DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS sessions (
    session_id       TEXT PRIMARY KEY,
    device_id        TEXT NOT NULL REFERENCES devices(device_id),
    token_issued_at  TEXT,
    auth_latency_ms  REAL
);

CREATE TABLE IF NOT EXISTS trust_scores (
    score_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id       TEXT NOT NULL REFERENCES devices(device_id),
    context_snapshot TEXT,
    score_value     INTEGER,
    computed_at     TEXT
);

CREATE TABLE IF NOT EXISTS access_decisions (
    decision_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT NOT NULL REFERENCES sessions(session_id),
    mqtt_topic      TEXT,
    decision        TEXT,
    decided_at      TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
    log_id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    decision_id             INTEGER NOT NULL REFERENCES access_decisions(decision_id),
    event_type              TEXT,
    compliance_control_ref  TEXT,
    logged_at               TEXT
);
"""


def init_audit_db() -> None:
    AUDIT_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(AUDIT_DB_PATH)
    try:
        conn.executescript(SCHEMA)
        conn.commit()
    finally:
        conn.close()
    log.info("audit database ready at %s", AUDIT_DB_PATH)


def _classify_compliance_control(event: dict) -> str:
    """Maps a decision's reason to an illustrative compliance control
    reference, supporting Objective vii (compliance traceability). These
    mappings are indicative for the prototype, not a legal determination
    — cite the relevant clauses precisely in Chapter 5's compliance
    matrix rather than relying on this string alone."""
    reason = (event.get("auth_reason") or "") + " " + (event.get("topic_reason") or "")
    reason = reason.lower()
    decision = event.get("final_decision", "deny")

    if "topic_ownership_violation" in reason or "malformed_topic" in reason:
        return "Least Privilege / Access Control (NIST SP 800-207; GDPR Art.32; HIPAA Sec.164.312(a)(1))"
    if any(k in reason for k in ("unknown_device", "invalid_signature", "stale_timestamp", "replay_detected", "missing_auth")):
        return "Authentication / Identity Verification (NDPA 2023 Pt.IV; HIPAA Sec.164.312(d))"
    if decision in ("allow", "step_up"):
        return "Access Granted, Logged for Accountability (GDPR Art.30; HIPAA Sec.164.312(b))"
    return "Risk-Based Authorization Denial (NIST SP 800-207)"


def record_audit_db(event: dict) -> None:
    device_id = event.get("device_id", "unknown")
    topic = event.get("topic", "")
    topic_parts = topic.split("/")
    device_type = topic_parts[1] if len(topic_parts) == 4 and topic_parts[0] == "healthcare" else "unknown"

    now_iso = datetime.now(timezone.utc).isoformat()
    session_id = str(uuid.uuid4())

    conn = sqlite3.connect(AUDIT_DB_PATH)
    try:
        conn.execute(
            "INSERT OR IGNORE INTO devices (device_id, device_type, first_seen, status) VALUES (?, ?, ?, 'active')",
            (device_id, device_type, now_iso),
        )

        conn.execute(
            "INSERT INTO sessions (session_id, device_id, token_issued_at, auth_latency_ms) VALUES (?, ?, ?, ?)",
            (session_id, device_id, event.get("received_at", now_iso), event.get("auth_latency_ms")),
        )

        context_snapshot = json.dumps({
            "auth_valid": event.get("auth_valid"),
            "auth_reason": event.get("auth_reason"),
            "trust_reason": event.get("trust_reason"),
            "trust_latency_ms": event.get("trust_latency_ms"),
            "used_cache": event.get("used_cache"),
            "cache_reason": event.get("cache_reason"),
            "payload_bytes": event.get("payload_bytes"),
            "topic_violation": event.get("topic_violation"),
        })
        cur = conn.execute(
            "INSERT INTO trust_scores (device_id, context_snapshot, score_value, computed_at) VALUES (?, ?, ?, ?)",
            (device_id, context_snapshot, event.get("trust_score"), now_iso),
        )

        cur = conn.execute(
            "INSERT INTO access_decisions (session_id, mqtt_topic, decision, decided_at) VALUES (?, ?, ?, ?)",
            (session_id, topic, event.get("final_decision", "deny"), now_iso),
        )
        decision_id = cur.lastrowid

        conn.execute(
            "INSERT INTO audit_log (decision_id, event_type, compliance_control_ref, logged_at) VALUES (?, ?, ?, ?)",
            (decision_id, event.get("event_type", "access_denied"), _classify_compliance_control(event), now_iso),
        )

        conn.commit()
    except sqlite3.Error as exc:
        log.error("audit DB write failed (event still recorded in gateway.log): %s", exc)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Local Policy Cache — last known-good decision per device, used when the
# auth-service or trust-engine is unreachable (Chapter 3, Figure 3.5).
# Persisted to disk so the cache survives a gateway restart, not just an
# in-memory dict that would reset along with the outage it's meant to
# protect against.
# ---------------------------------------------------------------------------

_policy_cache: dict = {}


def load_policy_cache() -> None:
    global _policy_cache
    if POLICY_CACHE_PATH.exists():
        try:
            _policy_cache = json.loads(POLICY_CACHE_PATH.read_text(encoding="utf-8"))
            log.info("loaded policy cache for %d device(s)", len(_policy_cache))
        except (json.JSONDecodeError, OSError) as exc:
            log.warning("could not load policy cache (%s), starting empty", exc)
            _policy_cache = {}
    else:
        _policy_cache = {}


def save_policy_cache() -> None:
    POLICY_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    POLICY_CACHE_PATH.write_text(json.dumps(_policy_cache), encoding="utf-8")


def update_cached_decision(device_id: str, decision: str, score: int) -> None:
    """Only called after a FRESH (live) decision — never overwrite the
    cache with a decision that was itself derived from the cache, or a
    stale entry could effectively become permanent."""
    _policy_cache[device_id] = {
        "decision": decision,
        "score": score,
        "cached_at": datetime.now(timezone.utc).isoformat(),
    }
    save_policy_cache()


def get_cached_decision(device_id: str) -> dict | None:
    return _policy_cache.get(device_id)


# ---------------------------------------------------------------------------
# Upstream connection (gateway -> core broker)
# ---------------------------------------------------------------------------

upstream_client = mqtt.Client(client_id="gateway-upstream")


def connect_upstream():
    connected = False
    while not connected and _running:
        try:
            upstream_client.connect(UPSTREAM_BROKER_HOST, UPSTREAM_BROKER_PORT, keepalive=30)
            connected = True
            log.info("connected to upstream core broker %s:%s", UPSTREAM_BROKER_HOST, UPSTREAM_BROKER_PORT)
        except (ConnectionRefusedError, OSError) as exc:
            log.warning("upstream broker not reachable yet (%s), retrying in 2s", exc)
            time.sleep(2)
    return connected


# ---------------------------------------------------------------------------
# Downstream connection (devices -> gateway-broker), the interception point
# ---------------------------------------------------------------------------

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        log.info("connected to gateway-broker %s:%s, subscribing to %s",
                  GATEWAY_BROKER_HOST, GATEWAY_BROKER_PORT, SUBSCRIBE_TOPIC)
        client.subscribe(SUBSCRIBE_TOPIC, qos=0)
    else:
        log.error("connection to gateway-broker failed, rc=%s", rc)


def call_auth_service(auth_block: dict) -> tuple[bool | None, str, float]:
    """Returns (valid_or_None, reason, latency_ms). valid is None if the
    auth service itself could not be reached (distinct from a real
    invalid-credential rejection, which is valid=False)."""
    start = time.monotonic()
    try:
        resp = _http_session.post(AUTH_SERVICE_URL, json=auth_block, timeout=AUTH_TIMEOUT_SECONDS)
        latency_ms = (time.monotonic() - start) * 1000
        resp.raise_for_status()
        data = resp.json()
        return bool(data.get("valid")), data.get("reason", "unknown"), latency_ms
    except requests.RequestException as exc:
        latency_ms = (time.monotonic() - start) * 1000
        log.error("auth service unreachable: %s", exc)
        return None, "auth_service_unreachable", latency_ms


def call_trust_engine(device_id: str, auth_valid: bool, auth_reason: str) -> tuple[dict | None, float]:
    """Returns (response_dict_or_None, latency_ms). None means the
    trust-engine could not be reached."""
    start = time.monotonic()
    try:
        resp = _http_session.post(
            TRUST_ENGINE_URL,
            json={
                "device_id": device_id,
                "auth_valid": auth_valid,
                "auth_reason": auth_reason,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
            timeout=TRUST_TIMEOUT_SECONDS,
        )
        latency_ms = (time.monotonic() - start) * 1000
        resp.raise_for_status()
        return resp.json(), latency_ms
    except requests.RequestException as exc:
        latency_ms = (time.monotonic() - start) * 1000
        log.error("trust engine unreachable: %s", exc)
        return None, latency_ms


def topic_owner_device_id(topic: str) -> str | None:
    """Expects topics shaped healthcare/{device_type}/{device_id}/telemetry
    and returns the device_id segment, or None if the topic doesn't match
    that shape at all (treated as suspicious by default)."""
    parts = topic.split("/")
    if len(parts) != 4 or parts[0] != "healthcare":
        return None
    return parts[2]


def check_topic_ownership(topic: str, claimed_device_id: str) -> tuple[bool, str]:
    """Micro-segmentation / topic-level access control (FR5, Chapter 3.2).
    This is a purely local, offline-safe check — no network call needed —
    so it applies regardless of whether auth-service/trust-engine were
    reachable. A device with a perfectly valid identity and a high trust
    score is still denied here if it tries to publish outside its own
    topic scope, which is the point: identity and trust answer "who are
    you", this answers "are you allowed to do THIS specific thing"."""
    owner = topic_owner_device_id(topic)
    if owner is None:
        return False, "malformed_topic_structure"
    if owner != claimed_device_id:
        return False, f"topic_ownership_violation (topic belongs to '{owner}', message claims '{claimed_device_id}')"
    return True, "ok"


def on_message(client, userdata, msg):
    received_at = datetime.now(timezone.utc).isoformat()

    try:
        payload = json.loads(msg.payload.decode("utf-8"))
        device_id = payload.get("device_id", "unknown")
        auth_block = payload.get("auth")
    except (ValueError, UnicodeDecodeError):
        device_id = "unknown"
        auth_block = None

    if not auth_block:
        deny_event = {
            "event_type": "access_denied",
            "topic": msg.topic,
            "device_id": device_id,
            "received_at": received_at,
            "final_decision": "deny",
            "auth_reason": "missing_auth_block",
            "used_cache": False,
        }
        record_event(deny_event)
        record_audit_db(deny_event)
        log.warning("%s <- %s — DENIED (no auth block present)", msg.topic, device_id)
        return

    auth_valid, auth_reason, auth_latency_ms = call_auth_service(auth_block)
    auth_reachable = auth_valid is not None

    trust_result = None
    trust_latency_ms = None
    used_cache = False
    cache_reason = None

    if auth_reachable:
        trust_result, trust_latency_ms = call_trust_engine(device_id, auth_valid, auth_reason)

    if auth_reachable and trust_result is not None:
        # Fresh, live decision from both services.
        final_decision = trust_result["decision"]
        score = trust_result["score"]
        trust_reason = trust_result["reason"]
        update_cached_decision(device_id, final_decision, score)
    else:
        # Either service was unreachable — fall back to the local policy
        # cache instead of failing the whole system open or closed.
        cached = get_cached_decision(device_id)
        used_cache = True
        if cached is not None:
            final_decision = cached["decision"]
            score = cached["score"]
            cache_reason = f"using cached decision from {cached['cached_at']}"
        else:
            final_decision = "deny"
            score = None
            cache_reason = "no cached policy available for this device"
        trust_reason = "N/A (service unreachable)" if trust_result is None else trust_result.get("reason", "")

    # --- Topic-level enforcement (micro-segmentation, FR5) ---
    # Applied regardless of the trust/cache outcome above, and regardless
    # of whether auth-service/trust-engine were reachable, since this is a
    # purely local check. A device can have valid identity and a high
    # trust score and still be denied here.
    topic_ok, topic_reason = check_topic_ownership(msg.topic, device_id)
    topic_violation = not topic_ok
    if topic_violation and final_decision in ("allow", "step_up"):
        final_decision = "deny"

    event = {
        "event_type": "access_allowed" if final_decision in ("allow", "step_up") else "access_denied",
        "topic": msg.topic,
        "device_id": device_id,
        "received_at": received_at,
        "auth_valid": auth_valid,
        "auth_reason": auth_reason,
        "auth_latency_ms": round(auth_latency_ms, 2) if auth_latency_ms is not None else None,
        "trust_score": score,
        "trust_reason": trust_reason,
        "trust_latency_ms": round(trust_latency_ms, 2) if trust_latency_ms is not None else None,
        "topic_violation": topic_violation,
        "topic_reason": topic_reason,
        "final_decision": final_decision,
        "used_cache": used_cache,
        "cache_reason": cache_reason,
        "payload_bytes": len(msg.payload),
    }
    record_event(event)
    record_audit_db(event)

    if final_decision in ("allow", "step_up"):
        tag = "ALLOWED" if final_decision == "allow" else "ALLOWED (step_up flagged)"
        cache_note = " [from cache — service unreachable]" if used_cache else ""
        log.info("%s <- %s score=%s — %s%s, forwarding upstream",
                  msg.topic, device_id, score, tag, cache_note)
        upstream_client.publish(msg.topic, msg.payload, qos=0)
    elif topic_violation:
        log.warning("%s <- %s score=%s — DENIED (%s)", msg.topic, device_id, score, topic_reason)
    else:
        cache_note = f" [{cache_reason}]" if used_cache else ""
        log.warning("%s <- %s score=%s — DENIED%s", msg.topic, device_id, score, cache_note)


def main():
    load_policy_cache()
    init_audit_db()
    if not connect_upstream():
        sys.exit(0)
    upstream_client.loop_start()

    downstream_client = mqtt.Client(client_id="gateway-downstream")
    downstream_client.on_connect = on_connect
    downstream_client.on_message = on_message

    connected = False
    while not connected and _running:
        try:
            downstream_client.connect(GATEWAY_BROKER_HOST, GATEWAY_BROKER_PORT, keepalive=30)
            connected = True
        except (ConnectionRefusedError, OSError) as exc:
            log.warning("gateway-broker not reachable yet (%s), retrying in 2s", exc)
            time.sleep(2)

    if not connected:
        sys.exit(0)

    record_event({
        "event_type": "gateway_started",
        "started_at": datetime.now(timezone.utc).isoformat(),
    })

    downstream_client.loop_start()

    while _running:
        time.sleep(1)

    downstream_client.loop_stop()
    downstream_client.disconnect()
    upstream_client.loop_stop()
    upstream_client.disconnect()
    log.info("stopped cleanly")


if __name__ == "__main__":
    main()
