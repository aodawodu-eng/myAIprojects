# Build Plan

Each phase produces something runnable. Work through them in order —
later phases assume earlier ones exist.

- [x] **Phase 0 — Environment setup**: Docker, Docker Compose, Python, git
  installed on the dev machine (Kali/Ubuntu/Debian all work identically).
- [x] **Phase 1 — Broker + simulated devices**: Mosquitto in Docker; three
  simulated constrained devices publishing synthetic vitals on a timer,
  each under CPU/memory limits. No auth, no enforcement yet.
- [x] **Phase 2 — Edge gateway skeleton (PEP)**: a gateway service sits
  between devices and the broker (as an MQTT bridge/proxy) and logs traffic.
  Still no enforcement — this phase just proves the interception point works.
- [x] **Phase 3 — Authentication service**: lightweight token issuance
  (HMAC-signed token per device) and a `/validate` endpoint. Devices present
  a token on connect; the gateway calls the auth service to check it.
- [x] **Phase 4 — Trust scoring + policy decision**: a simple, explainable
  rule-based scorer (token validity, time-since-last-seen, request rate) and
  a local policy cache at the gateway so decisions can still be made if the
  central Policy Decision Point is unreachable.
- [x] **Phase 5 — Enforcement + micro-segmentation**: the gateway actually
  allows/denies MQTT publish/subscribe per topic based on the decision.
  Docker networks (`device_net`, `gateway_net`, `broker_net`, `mgmt_net`)
  are introduced so a compromised device container cannot reach the broker
  or policy services directly.
- [x] **Phase 6 — Audit logging**: SQLite schema matching the ER diagram in
  Chapter 3 (`devices`, `sessions`, `trust_scores`, `access_decisions`,
  `audit_log`). Every decision writes a row. Implemented as a direct write
  from the gateway (not a separate service) — the gateway already has the
  full picture for each message in one place, so a network hop just to
  persist a log entry wasn't worth the extra failure point.
- [x] **Phase 7 — Instrumentation / metrics**: three host-side scripts —
  `collect_container_metrics.py` (docker stats polling for CPU/memory),
  `collect_availability.py` (live HTTP/TCP reachability checks against
  each service, giving a real uptime % rather than a log-derived proxy),
  and `summarize_metrics.py` (combines both with `logs/audit.db`'s
  auth/trust latency and checks the result against the actual Chapter 3.2
  thresholds — NFR1/NFR2/NFR3 — with a PASS/FAIL verdict per metric).
  Verified end-to-end by running the real `summarize_metrics.py` against
  synthetic fixture data (a fake audit.db, container_stats.csv, and
  availability.csv including a simulated outage row) — it correctly
  computed percentiles, correctly flagged the simulated outage as a FAIL
  against the 99.9% target, and produced valid JSON output.
- [x] **Phase 8 — Fault injection**: `tc netem` via `scripts/inject_fault.sh`
  (`delay` / `loss` / `disconnect` / `clear` / `status`), requiring
  `NET_ADMIN` + `iproute2` added to `auth-service` and `trust-engine` only
  — deliberately not the brokers, since those use the stock Alpine-based
  Mosquitto image and customising it wasn't worth the fragility for this
  scope. `disconnect` (netem, 100% loss) is kept distinct from `docker
  compose stop` from Phase 4 — one is a network-layer outage with the
  process still running, the other is a process-layer outage — and both
  are worth showing in Chapter 5 as different failure modes. Also added
  `scripts/severity_sweep.py`, which automates a 0/40/80/100% loss
  gradient against one target in a single run and tabulates uptime per
  level — found in practice that a single fixed loss% (e.g. 40%) doesn't
  reliably show a visible uptime drop, since TCP retransmission can absorb
  moderate loss within a health check's timeout; a gradient shows the
  actual resilience boundary instead of one arbitrary, possibly-misleading
  data point. Verified end-to-end with a mocked `inject_fault.sh` and a
  monkey-patched availability check that simulates a target degrading
  proportionally to the applied loss level — confirmed correct per-level
  orchestration, correct control-group (untouched target) behaviour, and
  valid CSV/JSON output.
- [x] **Phase 9 — CoAP/DTLS comparative path: SCOPED OUT.** Decision made
  after Phase 5: the MQTT pipeline (identity, trust scoring, offline
  fallback, topic enforcement, network segmentation) is solid and fully
  demonstrable; a second protocol stack in a second language (Java +
  Californium) was judged higher cost than value for the remaining time
  available. This is documented here as a deliberate, justified scope
  decision, not an oversight — see the note below for suggested wording
  for Chapter 5/6.
- [x] **Phase 10 — Results + presentation layer**: `scripts/generate_charts.py`
  (matplotlib) turns `metrics/summary.json` + `metrics/severity_sweep.json`
  + `metrics/container_stats.csv` into up to 7 PNGs — latency vs NFR1,
  decision breakdown, CPU/memory vs NFR2, availability vs NFR3 (auto
  colour-coded PASS/FAIL), the severity-sweep line chart, and a genuine
  CPU-over-time series. `scripts/generate_results_table.py` produces the
  companion Markdown table with an explicit PASS/FAIL verdict per NFR,
  ready to paste into Chapter 5. Both verified end-to-end against
  realistic synthetic fixtures matching the exact schemas
  `summarize_metrics.py`/`severity_sweep.py` actually produce (checked
  this carefully after finding schema drift earlier in the project — see
  note below); confirmed correct chart output, correct PASS/FAIL
  colour-coding, and graceful no-crash behaviour when inputs are missing.

## Operational hardening (beyond the original 10 phases)

Added after a defence-prep discussion identified real gaps between "working
prototype" and "production-ready" — specifically around backup/disaster
recovery and monitoring/alerting, which the original 10 phases didn't cover.

- [x] **Backup & disaster recovery** — `scripts/backup_audit_db.sh`. Uses
  SQLite's `.backup` API (not a plain file copy, which risks grabbing a
  half-written page from a live database) plus an integrity check on the
  resulting backup file, with automatic rotation. Verified end-to-end
  with a real SQLite database: confirmed the backup is byte-correct,
  confirmed rotation genuinely deletes the oldest files and keeps exactly
  the configured count (not just that it runs without error).
- [x] **Alerting** — `scripts/alert_monitor.py`. Rolling-window (default:
  last 20 checks), edge-triggered alerting against the NFR3 threshold,
  reusing `collect_availability.py`'s exact check logic so alerts and
  after-the-fact reports never disagree on what "reachable" means.
  Verified with a controlled healthy/degraded/healthy sequence fed
  through the real script: confirmed exactly one alert fires at the
  healthy-to-breaching transition and exactly one resolution fires at
  recovery (not spammed on every check while in a bad state), and
  confirmed the untouched control target never alerts.
- [ ] **CI/CD pipeline** — not yet built; deferred, lower priority than
  backup/alerting for defence purposes. A GitHub Actions workflow running
  `py_compile` + `docker compose build` on push would be realistic scope
  if there's time.
- [ ] **Incident response runbook** — not yet written; this is a
  documentation task (who gets paged, what the fallback runbook is), not
  a code task. Worth writing as part of Chapter 6.
- **Explicitly out of scope**: real SIEM integration, paging/on-call
  integration (email/SMS/Slack/PagerDuty), tested cross-region DR
  failover. These require organizational infrastructure and ongoing
  operational commitment that doesn't make sense to fake in a student
  prototype — named honestly in Chapter 6 as future work rather than
  built as a hollow imitation.

## Monitoring Dashboard (GUI, beyond the original 10 phases)

- [x] **Web-based monitoring dashboard** — `dashboard/` (Flask + vanilla
  JS/CSS, no build step, no frontend framework, no CDN dependency). Runs
  as a 9th container, auto-refreshing every 3s: a live green/red
  system-status pill, NFR1/2/3 cards with animated SVG gauge rings, an
  SVG donut chart for the decision breakdown, device cards with
  colour-coded trust bars, an alert feed, and a scrollable recent-decisions
  table. Deliberately read-only and file-based — no network path to
  auth-service/trust-engine/either broker, only read-only volume mounts
  of `logs/` and `metrics/`; placed alone on `mgmt_net` (reserved for
  exactly this back in Phase 5) rather than given broader network access
  it doesn't need. Verified end-to-end with Flask's test client against a
  real synthetic `audit.db` (correct device joins, correct newest-first
  alert ordering, correct PASS/FAIL logic on all three NFRs) and rendered
  live in a headless browser (Playwright) in both a "degraded" state
  (active alert, NFR3 failing — red pill, red ring) and a fully healthy
  state (green pill, all rings green), confirming the status-pill logic
  correctly reflects both NFR verdicts and live alert state, not just one
  or the other.

## Performance finding: trust-engine latency (post-deployment, real measurement)

Real usage on the candidate's own machine surfaced `trust_latency_ms`
figures far outside the pattern of every other measured latency in the
system (avg 317ms, p95 1429ms, max 4020ms, versus auth_latency_ms's
avg 7.5ms, p95 16.75ms). Investigated and addressed in two independent
steps, each verified separately rather than assumed:

1. **Debounced state persistence** (`trust-engine/trust_engine.py`) — the
   original implementation wrote the entire trust-history dictionary to
   disk on every single `/trust-score` call. Changed to write at most
   once per 2 seconds (atomic tmp-file + rename), verified with a direct
   test showing 20 rapid calls collapse into exactly 1 real disk write.
   Real-world effect after deployment: avg dropped from 317ms to 110ms
   (~65% reduction) — a genuine, measured improvement, but not a full fix.
2. **HTTP connection reuse** (`gateway/gateway_service.py`) — the
   gateway was calling `requests.post()` directly for every request to
   auth-service/trust-engine, opening a brand-new TCP connection each
   time instead of reusing one. Replaced with a shared, connection-pooling
   `requests.Session()`. Verified with a real local HTTP server counting
   distinct TCP connections: confirmed the old pattern opened one
   connection per call (20 calls -> 20 connections) and the new pattern
   reuses a single connection (20 calls -> 1 connection).

**Still unresolved after both fixes**: p95 and max remain high (1012ms /
3040ms even after both changes). This points to something outside
either of the two mechanisms addressed above — most likely host-level
resource contention (the test machine runs 9 containers simultaneously;
if the host itself, or the VM it's running in, is under CPU/memory
pressure, that would produce exactly this kind of erratic, right-skewed
latency independent of anything the application code is doing). Not yet
confirmed — needs `collect_container_metrics.py` run concurrently with
real traffic, correlated against host-level monitoring (`htop`/`top`)
during the same window, to see whether latency spikes line up with host
CPU spikes. Worth reporting honestly in Chapter 5 as: two real,
measured, partial improvements, plus a documented but not-yet-isolated
remaining cause — rather than either overclaiming a full fix or hiding
the investigation.

## Notes on scope decisions

- **Phase 9 (CoAP/DTLS) was cut** after Phase 5, deliberately, not by
  running out of time unexpectedly. Suggested wording for Chapter 5 or 6:

  > "A comparative CoAP/DTLS 1.3 path (via Eclipse Californium) was
  > evaluated during design (Chapter 3) as a lighter-weight alternative
  > transport for constrained devices. Implementation was scoped to the
  > MQTT path only for this project cycle, in order to prioritise depth
  > and robustness of the core Zero Trust pipeline — identity
  > verification, trust scoring, offline policy caching, and topic-level
  > enforcement — over breadth across two protocol stacks. A CoAP/DTLS
  > comparative implementation is recommended as future work, and the
  > architectural provision for it (Figure 3.1) remains valid should it be
  > pursued."

  This is a normal, defensible scope decision for a Master's project —
  say it plainly rather than let it look like an oversight.
- Keep trust scoring **rule-based and explainable** rather than ML-based —
  this matches what Chapter 1/2 already committed to (AI/ML explicitly
  scoped out as too resource-heavy for constrained devices) and is much
  easier to defend in a viva.
