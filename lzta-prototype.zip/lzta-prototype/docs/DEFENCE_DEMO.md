# LZTA Defence Demo Script

A start-to-finish script for demonstrating the prototype live. Follow it
in order — each step builds the story for the next one. Rehearse this at
least once, fully, on the exact machine you'll present from.

**Total live demo time: ~14–17 minutes** if run at a normal pace. Steps
marked **(optional / time-permitting)** can be cut if your slot is tight.

---

## Part 0 — The night before (not part of the live demo)

Do this *before* defence day, not in front of examiners. It removes the
slowest and most failure-prone steps from the live path.

1. **Pull the machine you'll actually present from**, not a different
   laptop "like it." Permissions, Docker versions, and leftover state
   from testing all differ machine to machine.

2. **Fully clean and rebuild:**
   ```bash
   cd ~/Desktop/lzta-prototype
   sudo docker compose down
   sudo docker compose up --build -d
   sudo docker compose ps
   ```
   Confirm all **9 services** show `Up`.

3. **Clear any leftover fault-injection rules** — this has bitten you
   before (a forgotten `disconnect` rule on `trust-engine` looked like a
   real outage). Check both:
   ```bash
   ./scripts/inject_fault.sh status trust-engine
   ./scripts/inject_fault.sh status auth-service
   ```
   Both should print `qdisc noqueue 0: root refcnt 2` (the clean,
   no-fault state). If either shows a `netem` line, clear it:
   ```bash
   ./scripts/inject_fault.sh clear trust-engine
   ./scripts/inject_fault.sh clear auth-service
   ```

4. **Back up your current audit database** — if anything goes wrong
   during rehearsal or the real demo, you can restore instantly instead
   of starting from zero:
   ```bash
   ./scripts/backup_audit_db.sh
   ```

5. **Pre-generate your charts and results table** so you have them ready
   as static evidence even if live commands misbehave in the room:
   ```bash
   python3 scripts/collect_container_metrics.py --interval 5 --duration 60 &
   python3 scripts/collect_availability.py --interval 2 --duration 60
   python3 scripts/summarize_metrics.py
   python3 scripts/generate_charts.py
   python3 scripts/generate_results_table.py
   ```
   Also **run a full severity sweep once now**, not live during the
   demo — it takes several minutes and you don't want that eating your
   slot:
   ```bash
   sudo -v
   python3 scripts/severity_sweep.py --target trust-engine
   python3 scripts/generate_charts.py   # regenerate to include severity_sweep.png
   ```
   Keep `metrics/charts/*.png` and `metrics/results_table.md` open in a
   separate window/tab as your fallback evidence.

6. **Do one full dry run of Parts 1–7 below**, timed, so you know what
   it feels like and how long it actually takes you.

---

## Part 1 — Open with the dashboard (∼1–2 min)

**Do:**
```bash
sudo docker compose ps
```
Point out: 9 containers, all `Up`. Then open **http://localhost:5050**
in a browser and leave it open in a tab for the rest of the demo.

**Say:** "This is a live monitoring console for the whole system —
Zero Trust deployments in the real world always have something like
this. Everything I show from here on will update on this screen in
real time, not just in the terminal."

**Give a quick tour before moving on** (10–15 seconds each, don't over-explain
yet — you'll come back to most of these with real data later):
- **Status pill** (top right) — green "All Systems Operational" right now
- **NFR compliance gauges** — live PASS/FAIL against your Chapter 3.2 thresholds
- **System topology** — a live diagram of the actual architecture from
  Chapter 3, Figure 3.1; nodes will turn red later when something breaks
- **Devices, decision breakdown, decisions-over-time** — self-explanatory,
  will fill in as you go
- **Compliance coverage** and **Recommendations** panels — say "I'll come
  back to these once there's something interesting to show"

**Mention the Pause button** in the header: "If I need to stop and explain
something without the screen changing under me, I can freeze it here" —
useful to know it exists, you may not need it yet.

---

## Part 2 — Normal operation (∼1 min)

**Do:**
```bash
sudo docker compose logs -f gateway
```
Let it scroll for ~10 seconds.

**Say:** "Three simulated constrained medical devices — a glucose
monitor, pulse oximeter, and heart-rate monitor — are publishing
synthetic vitals every 5 seconds. Every single message passes through
this gateway, which is the enforcement point in the architecture."

Press `Ctrl+C` to stop tailing (containers keep running).

---

## Part 3 — Authentication: prove identity is actually checked (∼2 min)

This is your first "it's not just a pipe" moment: a message with a
**wrong signature** gets rejected.

**Do:**
```bash
mosquitto_pub -h localhost -p 1883 \
  -t 'healthcare/glucose_monitor/glucose-01/telemetry' \
  -m '{"device_id":"glucose-01","auth":{"device_id":"glucose-01","timestamp":"2026-08-01T00:00:00+00:00","nonce":"fake","signature":"deadbeef"}}'

sudo docker compose logs gateway | grep "invalid_signature" | tail -3
```

**Say:** "Every device signs its messages with a lightweight HMAC token,
not full TLS — appropriate for constrained hardware. I just sent a
message claiming to be the glucose monitor, but with a fake signature.
The gateway called the authentication service, which rejected it — you
can see `invalid_signature` right there, and it never reached the
broker."

**Point at the dashboard:** the new denied decision should appear in
"Recent Access Decisions," badge colored red.

**(optional)** Click the **"Deny"** filter pill above the decisions
table to isolate just this event — a good way to show "here's everything
the system has ever blocked" if an examiner asks.

---

## Part 4 — Authorization: valid identity, still denied (∼2–3 min)

**This is your strongest single moment.** It proves the system
distinguishes *authentication* ("who are you") from *authorization*
("are you allowed to do this specific thing") — the core Zero Trust
principle from your literature review.

**Do:** (this uses glucose-01's *real*, valid credentials, but targets a
topic that isn't glucose-01's)
```bash
python3 - << 'EOF'
import hmac, hashlib, secrets, json, subprocess
from datetime import datetime, timezone

DEVICE_ID = "glucose-01"
SECRET = "WffyoO8zaGtW7I8fg7AOTAE3v7rF3CSG"

ts = datetime.now(timezone.utc).isoformat()
nonce = secrets.token_hex(8)
sig = hmac.new(SECRET.encode(), f"{DEVICE_ID}|{ts}|{nonce}".encode(), hashlib.sha256).hexdigest()

payload = {"device_id": DEVICE_ID, "auth": {"device_id": DEVICE_ID, "timestamp": ts, "nonce": nonce, "signature": sig}}

subprocess.run(["mosquitto_pub", "-h", "localhost", "-p", "1883",
    "-t", "healthcare/heart_rate_monitor/heartrate-01/telemetry",
    "-m", json.dumps(payload)])
print("published")
EOF

sudo docker compose logs gateway | grep "glucose-01" | grep "heart_rate_monitor" | tail -1
```

**Say:** "This message has a completely valid, correctly signed
identity — it really is glucose-01. Watch what happens when it tries to
publish on the heart-rate monitor's topic instead of its own." *(run
the command)* "Denied — `topic_ownership_violation` — even though
identity passed and the trust score was high. Authentication succeeding
doesn't mean authorization succeeds. That distinction is enforced right
here, at the gateway."

**(optional)** Click glucose-01's device card on the dashboard — its
drill-down shows the full recent history for that specific device,
including this denial, with a trust-score trend sparkline. Good if an
examiner asks "can you show me everything about one specific device."

---

## Part 5 — Audit trail: prove every decision is logged (∼1–2 min)

**Do:**
```bash
sqlite3 -header -column logs/audit.db "
SELECT ad.decided_at, ad.mqtt_topic, ad.decision, al.compliance_control_ref
FROM access_decisions ad
JOIN audit_log al ON ad.decision_id = al.decision_id
ORDER BY ad.decision_id DESC LIMIT 5;
"
```

**Say:** "Both of those denials — and every allow — are written to a
structured SQLite database matching the schema in Chapter 3, including a
mapped compliance control reference. This is what supports the
compliance traceability objective." Then gesture at the dashboard's
"Recent Access Decisions" table — same data, live.

**Point at the "Compliance Coverage" panel** on the dashboard — it
groups every logged decision by which control it maps to (e.g. "Least
Privilege / Access Control," "Authentication / Identity Verification"),
with live counts. Say: "This is the same compliance-mapping objective
from Chapter 1, but queryable and visible in real time rather than a
one-off report."

---

## Part 6 — Resilience: alerting + offline fallback together (∼4–5 min)

This is the most technically important result in your thesis — the
system staying useful when a backend service goes down, detecting it
automatically, and now, visibly, on one screen. This is your best single
moment in the whole demo — take your time here.

**Do — start the alert monitor** (this is what actually detects the
outage and writes to `logs/alerts.log`; the dashboard visualizes it, but
doesn't do the detection itself):
```bash
python3 scripts/alert_monitor.py --window 5 --interval 1
```
Leave this running in its own terminal, visible if possible.

**Say, before triggering anything:** "Right now, everything on the
dashboard is healthy — green status pill, all topology nodes calm.
Watch all of it at once when I cut off the trust-scoring service."

**Do — in another terminal, cut off trust-engine:**
```bash
./scripts/inject_fault.sh disconnect trust-engine
```

**Say (while it's degrading):** "I've just cut the network path to the
trust-scoring service entirely — this simulates the kind of
intermittent connectivity a clinical network genuinely experiences."

**Point out, as they happen (~5–10 seconds), on the dashboard itself —
this is the moment to slow down and let it land:**
- A **toast notification** slides in from the corner announcing the alert
- The **topology diagram**'s trust-engine node turns **red and pulses**
- The **status pill** flips from green to **red "Degraded"**
- The **Recommendations panel** populates with plain-English guidance
  (e.g. checking for a leftover fault rule, then container health)
- The **alert monitor terminal** prints a loud `ALERT:` banner
- `sudo docker compose logs gateway | tail -5` shows `ALLOWED [from
  cache — service unreachable]` — devices are *still being served*, not
  blocked, because the gateway fell back to its last-known-good cached
  decision per device

**Say:** "The gateway isn't guessing or failing open blindly — it's
using the last decision it actually knows to be good for each specific
device. A brand-new, never-seen device would still be denied here, since
there's nothing safe to fall back to for it. And notice I didn't have to
go looking for any of this — the topology, the alert, and the
recommendation all surfaced on their own."

**Do — restore it:**
```bash
./scripts/inject_fault.sh clear trust-engine
```
Point out: the alert monitor prints `[RESOLVED]`, the topology node
returns to blue/calm, the status pill returns to green, the
recommendations panel clears, and `logs/alerts.log` now has a matched
raised/resolved pair. Stop the alert monitor with `Ctrl+C`.

---

## Part 7 — The quantitative payoff: severity sweep (∼2 min)

**Don't run this live** — you already ran it the night before. Show the
result instead.

**Do:** open `metrics/charts/severity_sweep.png`.

**Say:** "Rather than a single up/down test, I measured availability
across a full gradient of network degradation — 0%, 40%, 80%, and 100%
packet loss — against the trust-engine specifically, while a control
service was left untouched. You can see availability holds, then
degrades, then collapses at full disconnection, while the control stays
flat at 100% throughout. This shows *where* the resilience boundary
actually sits, not just that the system survived one arbitrary test."

**(optional / time-permitting):** open `metrics/results_table.md` and
show the PASS/FAIL verdicts against your Chapter 3.2 thresholds
(NFR1/2/3) as a summary.

---

## Part 8 — Close (∼1 min)

**Say something like:** "To summarize what you've just seen: identity
is verified cryptographically, authorization is enforced independently
of identity, every decision is logged and mapped to a compliance
control, the system detects and alerts on its own degradation
automatically, and it remains functional — using cached trust decisions
— even when a central policy service is completely unreachable. That
last point is the direct answer to this project's core research
question about reducing cloud dependency in constrained healthcare IoT."

---

## Troubleshooting quick-reference (keep this visible, don't scroll for it live)

| Symptom | Likely cause | Fix |
|---|---|---|
| `permission denied` on docker commands | not in docker group / fresh shell | `sudo docker ...` or `newgrp docker` |
| Gateway shows everything as `ALLOWED [from cache]` unexpectedly | leftover fault rule from earlier testing | `./scripts/inject_fault.sh status <target>`, then `clear` if active |
| `summarize_metrics.py` says "no data" | ran it from the wrong directory | `pwd` — must be inside `~/Desktop/lzta-prototype` |
| `logs/audit.db` missing/empty | file was deleted, or gateway never started | `sudo docker compose restart gateway`, then let traffic run a minute |
| Dashboard tab shows nothing | forgot `docker compose up` included it | `sudo docker compose ps` — confirm `dashboard` shows `Up` |
| Any container not `Up` | stale build after a code change | `sudo docker compose up --build -d` |

**If something breaks mid-demo and you can't fix it in ~15 seconds**:
stop troubleshooting live, say "let me show you the result from this
morning's run instead," and switch to `metrics/charts/` and
`metrics/results_table.md`. A calm pivot to pre-generated evidence reads
far better than a long live debugging session in front of examiners.

**If you get a tricky question mid-demo and want the screen to stop
moving while you answer**, click the dashboard's **Pause** button —
freezes the current view without losing data, click again to resume.
