"""
device_simulator.py

Simulates a single constrained medical IoT device that publishes synthetic
vitals to an MQTT broker on a timer. One container = one simulated device.
Which device it pretends to be, and how it behaves, is entirely controlled
by environment variables (see docker-compose.yml), so the same image is
reused for the glucose monitor, pulse oximeter, and heart-rate monitor.

Phase 1 scope only: no authentication, no TLS, no trust scoring. This will
be extended in later phases (device identity token presented on connect,
etc.) without changing the container image itself where possible.
"""

import hashlib
import hmac
import json
import logging
import os
import random
import secrets
import signal
import sys
import time
from datetime import datetime, timezone

import paho.mqtt.client as mqtt

# ---------------------------------------------------------------------------
# Configuration (all from environment variables, with sensible defaults so
# the script also runs standalone on a host for quick testing)
# ---------------------------------------------------------------------------

DEVICE_ID = os.environ.get("DEVICE_ID", "device-01")
DEVICE_TYPE = os.environ.get("DEVICE_TYPE", "generic_sensor")
DEVICE_SECRET = os.environ.get("DEVICE_SECRET", "")
MQTT_HOST = os.environ.get("MQTT_HOST", "localhost")
MQTT_PORT = int(os.environ.get("MQTT_PORT", "1883"))
PUBLISH_INTERVAL_SECONDS = float(os.environ.get("PUBLISH_INTERVAL", "5"))
TOPIC = f"healthcare/{DEVICE_TYPE}/{DEVICE_ID}/telemetry"

if not DEVICE_SECRET:
    logging.warning("DEVICE_SECRET is not set — messages will fail authentication at the gateway")

logging.basicConfig(
    level=logging.INFO,
    format=f"[{DEVICE_ID}] %(asctime)s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(DEVICE_ID)

_running = True


def _handle_shutdown(signum, frame):
    global _running
    log.info("shutdown signal received, stopping publish loop")
    _running = False


signal.signal(signal.SIGTERM, _handle_shutdown)
signal.signal(signal.SIGINT, _handle_shutdown)


# ---------------------------------------------------------------------------
# Synthetic reading generators — one per simulated device type.
# All values are synthetic and used only for functional/performance
# testing, consistent with the Scope statement that no live patient data
# is processed at any stage.
# ---------------------------------------------------------------------------

def _reading_glucose_monitor() -> dict:
    return {"glucose_mg_dl": round(random.uniform(70, 180), 1)}


def _reading_pulse_oximeter() -> dict:
    return {
        "spo2_percent": round(random.uniform(94, 100), 1),
        "heart_rate_bpm": round(random.uniform(55, 110), 0),
    }


def _reading_heart_rate_monitor() -> dict:
    return {"heart_rate_bpm": round(random.uniform(55, 110), 0)}


READING_GENERATORS = {
    "glucose_monitor": _reading_glucose_monitor,
    "pulse_oximeter": _reading_pulse_oximeter,
    "heart_rate_monitor": _reading_heart_rate_monitor,
}


def sign_message(timestamp: str, nonce: str) -> str:
    """HMAC-SHA256 over device_id|timestamp|nonce, matching the scheme the
    auth service verifies. See Chapter 3.2 (FR2 — Lightweight
    Authentication) for the rationale for choosing HMAC over full TLS."""
    canonical = f"{DEVICE_ID}|{timestamp}|{nonce}"
    return hmac.new(
        DEVICE_SECRET.encode("utf-8"),
        canonical.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def build_payload() -> dict:
    generator = READING_GENERATORS.get(DEVICE_TYPE)
    reading = generator() if generator else {"value": round(random.uniform(0, 100), 2)}

    timestamp = datetime.now(timezone.utc).isoformat()
    nonce = secrets.token_hex(8)

    payload = {
        "device_id": DEVICE_ID,
        "device_type": DEVICE_TYPE,
        "timestamp": timestamp,
        "auth": {
            "device_id": DEVICE_ID,
            "timestamp": timestamp,
            "nonce": nonce,
            "signature": sign_message(timestamp, nonce),
        },
    }
    payload.update(reading)
    return payload


# ---------------------------------------------------------------------------
# MQTT connection handling
# ---------------------------------------------------------------------------

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        log.info("connected to broker %s:%s", MQTT_HOST, MQTT_PORT)
    else:
        log.error("connection failed with result code %s", rc)


def on_disconnect(client, userdata, rc):
    if rc != 0:
        log.warning("unexpected disconnect (rc=%s), paho will attempt to reconnect", rc)


def main():
    client = mqtt.Client(client_id=DEVICE_ID, clean_session=True)
    client.on_connect = on_connect
    client.on_disconnect = on_disconnect

    # Retry the initial connection since the broker container may not be
    # ready yet when this container starts (no orchestrated healthcheck
    # dependency wired up in Phase 1).
    connected = False
    while not connected and _running:
        try:
            client.connect(MQTT_HOST, MQTT_PORT, keepalive=30)
            connected = True
        except (ConnectionRefusedError, OSError) as exc:
            log.warning("broker not reachable yet (%s), retrying in 2s", exc)
            time.sleep(2)

    if not connected:
        sys.exit(0)

    client.loop_start()

    while _running:
        payload = build_payload()
        result = client.publish(TOPIC, json.dumps(payload), qos=0)
        if result.rc == mqtt.MQTT_ERR_SUCCESS:
            log.info("published to %s: %s", TOPIC, json.dumps(payload))
        else:
            log.warning("publish failed with rc=%s", result.rc)
        time.sleep(PUBLISH_INTERVAL_SECONDS)

    client.loop_stop()
    client.disconnect()
    log.info("stopped cleanly")


if __name__ == "__main__":
    main()
