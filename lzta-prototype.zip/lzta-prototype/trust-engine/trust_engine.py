"""
trust_engine.py

Phase 4 scope: the Trust Scoring Engine from Chapter 3's architecture
(Figure 3.1). It receives the outcome of the auth-service's identity
check and turns it, plus a device's short-term history, into a numeric
trust score (0-100) and a policy decision (allow / step_up / deny).

Deliberately rule-based and fully explainable, NOT machine-learned — this
matches the scope decision already made in Chapters 1-2 (ML explicitly
ruled out as too resource-heavy to justify for constrained-device
Zero Trust, and harder to defend/audit for a healthcare compliance
context). Every point added or subtracted has a stated reason, and the
response includes that reasoning so the gateway's audit log can record
*why* a score was what it was, not just the number.

Scoring model (all weights are intentionally simple integers so they are
easy to tune and easy to justify in Chapter 5's evaluation):

    start                                   = 50
    + 30  if this message's identity check passed (auth_valid)
    - 40  if this message's identity check failed
    + 10  if the device has been known for more than ESTABLISHED_AGE_SECONDS
    - 15  per recent auth failure in the last RECENT_WINDOW_SECONDS (capped)
    - 20  if messages are arriving faster than MIN_EXPECTED_INTERVAL_SECONDS
          apart (possible flooding / malfunction / spoofing burst)

    score is clamped to [0, 100]

Decision thresholds:
    score >= ALLOW_THRESHOLD      -> "allow"
    STEP_UP_THRESHOLD <= score    -> "step_up"   (flagged, but still
                                                   forwarded in this phase —
                                                   see note below)
    score <  STEP_UP_THRESHOLD    -> "deny"

Known limitation (stated openly, not hidden): "step_up" is meant to
represent a request for additional verification (e.g. re-authentication)
before being fully trusted. This prototype does not implement an actual
step-up challenge/response flow — it currently treats step_up the same
as allow, but logs it distinctly so the audit trail still shows how often
it would have triggered. Implementing a real step-up flow is listed as
future work in Chapter 5/6.
"""

import json
import logging
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Tuple

from fastapi import FastAPI
from pydantic import BaseModel

logging.basicConfig(
    level=logging.INFO,
    format="[trust-engine] %(asctime)s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("trust-engine")

STATE_PATH = Path("/app/state/trust_state.json")

ESTABLISHED_AGE_SECONDS = 60
RECENT_WINDOW_SECONDS = 300
MAX_FAILURE_PENALTY_EVENTS = 3
MIN_EXPECTED_INTERVAL_SECONDS = 1.0

ALLOW_THRESHOLD = 70
STEP_UP_THRESHOLD = 40

app = FastAPI(title="LZTA Trust Scoring Engine", version="0.1.0")

# device_id -> {"first_seen": epoch, "last_seen": epoch,
#               "recent_events": [[epoch, valid_bool], ...]}
_history: Dict[str, dict] = {}

# Guards all reads/writes of _history — FastAPI runs sync route handlers
# (like trust_score() below) in a thread pool, so concurrent requests can
# genuinely race on this dict without a lock, not just a theoretical
# concern.
_history_lock = threading.Lock()

# Debounced persistence: writing the ENTIRE history to disk on every
# single request (the original implementation) was found in real testing
# to add 100s of ms to trust_latency_ms per request, and spike into
# multi-second territory under load — a full synchronous disk write per
# request scales badly, and disk latency variance (fsync, journaling,
# whatever filesystem the Docker volume sits on) shows up directly as
# trust-engine response latency. Persisting at most once every
# SAVE_INTERVAL_SECONDS instead keeps state durable across restarts
# (this was never meant to be a strict consistency guarantee anyway — see
# the nonce-cache-resets-on-restart limitation already noted for
# auth-service) while removing per-request disk I/O from the request path
# entirely in the common case.
SAVE_INTERVAL_SECONDS = 2.0
_last_save_time = 0.0
_save_lock = threading.Lock()


def load_state() -> None:
    global _history
    if STATE_PATH.exists():
        try:
            _history = json.loads(STATE_PATH.read_text(encoding="utf-8"))
            log.info("loaded trust history for %d device(s)", len(_history))
        except (json.JSONDecodeError, OSError) as exc:
            log.warning("could not load trust state (%s), starting fresh", exc)
            _history = {}
    else:
        _history = {}


def save_state() -> None:
    """Atomic write (temp file + rename) so a crash mid-write can never
    leave a half-written, corrupt state file — the same principle used
    for the audit database backups."""
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = STATE_PATH.with_suffix(".tmp")
    with _history_lock:
        data = json.dumps(_history)
    tmp_path.write_text(data, encoding="utf-8")
    os.replace(tmp_path, STATE_PATH)


def maybe_save_state(force: bool = False) -> None:
    """Debounced persistence — see the comment above SAVE_INTERVAL_SECONDS
    for why this isn't a save-on-every-request call anymore."""
    global _last_save_time
    with _save_lock:
        now = time.time()
        if not force and (now - _last_save_time) < SAVE_INTERVAL_SECONDS:
            return
        _last_save_time = now
    save_state()


class TrustScoreRequest(BaseModel):
    device_id: str
    auth_valid: bool
    auth_reason: str
    timestamp: str


class TrustScoreResponse(BaseModel):
    device_id: str
    score: int
    decision: str
    reason: str
    first_seen: str
    last_seen: str
    recent_failure_count: int


@app.on_event("startup")
def on_startup():
    load_state()


@app.on_event("shutdown")
def on_shutdown():
    # Force a final flush on clean shutdown so a debounce window doesn't
    # cost you the last couple of seconds of history on a normal restart
    # (e.g. `docker compose restart trust-engine`), as opposed to a hard
    # crash, which the debounce was always allowed to lose a little state
    # against.
    maybe_save_state(force=True)


@app.get("/health")
def health():
    return {"status": "ok", "devices_tracked": len(_history)}


def _prune_recent_events(events: List[List], now: float) -> List[List]:
    return [e for e in events if now - e[0] <= RECENT_WINDOW_SECONDS]


@app.post("/trust-score", response_model=TrustScoreResponse)
def trust_score(req: TrustScoreRequest):
    now = time.time()
    reasons: List[str] = []

    with _history_lock:
        record = _history.get(req.device_id)
        is_new_device = record is None
        if is_new_device:
            record = {"first_seen": now, "last_seen": now, "recent_events": []}
            reasons.append("new device (no prior history)")

        age_seconds = now - record["first_seen"]
        time_since_last_seen = now - record["last_seen"] if not is_new_device else None

        record["recent_events"] = _prune_recent_events(record["recent_events"], now)
        record["recent_events"].append([now, req.auth_valid])

        recent_failures = sum(1 for _, valid in record["recent_events"] if not valid)

        record["last_seen"] = now
        _history[req.device_id] = record

    # --- scoring ---
    score = 50

    if req.auth_valid:
        score += 30
        reasons.append("identity check passed (+30)")
    else:
        score -= 40
        reasons.append(f"identity check failed: {req.auth_reason} (-40)")

    if age_seconds > ESTABLISHED_AGE_SECONDS:
        score += 10
        reasons.append(f"device established for {int(age_seconds)}s (+10)")
    else:
        reasons.append(f"device recently seen for the first time ({int(age_seconds)}s old, no bonus)")

    failure_penalty_events = min(recent_failures, MAX_FAILURE_PENALTY_EVENTS)
    if failure_penalty_events > 0:
        penalty = 15 * failure_penalty_events
        score -= penalty
        reasons.append(f"{recent_failures} recent auth failure(s) in last {RECENT_WINDOW_SECONDS}s (-{penalty})")

    if time_since_last_seen is not None and time_since_last_seen < MIN_EXPECTED_INTERVAL_SECONDS:
        score -= 20
        reasons.append(f"messages arriving faster than {MIN_EXPECTED_INTERVAL_SECONDS}s apart, possible flood (-20)")

    score = max(0, min(100, score))

    if score >= ALLOW_THRESHOLD:
        decision = "allow"
    elif score >= STEP_UP_THRESHOLD:
        decision = "step_up"
    else:
        decision = "deny"

    maybe_save_state()

    reason_str = "; ".join(reasons)
    log.info("%s -> score=%d decision=%s (%s)", req.device_id, score, decision, reason_str)

    return TrustScoreResponse(
        device_id=req.device_id,
        score=score,
        decision=decision,
        reason=reason_str,
        first_seen=datetime.fromtimestamp(record["first_seen"], tz=timezone.utc).isoformat(),
        last_seen=datetime.fromtimestamp(record["last_seen"], tz=timezone.utc).isoformat(),
        recent_failure_count=recent_failures,
    )
