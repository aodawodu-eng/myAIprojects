"""
auth_service.py

Phase 3 scope: the Authentication Service from Chapter 3's architecture
(Figure 3.1, Policy & Identity Layer). It validates the lightweight
HMAC-signed token each device attaches to every message it publishes.

This is deliberately NOT full mutual-TLS/PKI — see the Chapter 3
justification for why a pre-shared-key + HMAC scheme was chosen for
constrained devices instead. Each device was provisioned (out of band,
represented here by device_registry.json) with a shared secret. To prove
its identity on every message, a device signs:

    device_id | timestamp | nonce

with HMAC-SHA256 using that shared secret. This service recomputes the
same HMAC and compares it, using a constant-time comparison to avoid
timing side-channels.

Three checks are performed, in order, each with its own rejection reason
(useful for your Chapter 5 results — you can report *why* requests were
denied, not just how many):

  1. known_device      — is this device_id in the registry at all?
  2. fresh_timestamp    — is the timestamp within an acceptable clock-skew
                           / network-delay tolerance window?
  3. nonce_not_reused   — has this exact (device_id, nonce) pair been seen
                           before? (replay protection)
  4. valid_signature    — does the recomputed HMAC match?

Limitation (documented on purpose, not hidden): the nonce cache is
in-memory only and resets if this service restarts. For a prototype this
is an acceptable, explicitly-scoped simplification — a production system
would back this with a shared store (e.g. Redis) so replay protection
survives restarts and works across multiple gateway instances.
"""

import hashlib
import hmac
import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Tuple

from fastapi import FastAPI
from pydantic import BaseModel

logging.basicConfig(
    level=logging.INFO,
    format="[auth-service] %(asctime)s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("auth-service")

REGISTRY_PATH = Path("/app/device_registry.json")
TIMESTAMP_TOLERANCE_SECONDS = 30
NONCE_CACHE_TTL_SECONDS = 300  # how long we remember a nonce before forgetting it

app = FastAPI(title="LZTA Authentication Service", version="0.1.0")

# device_id -> {"secret": ..., "device_type": ..., "status": ...}
_registry: Dict[str, dict] = {}

# (device_id, nonce) -> first_seen_epoch_seconds
_seen_nonces: Dict[Tuple[str, str], float] = {}


def load_registry() -> None:
    global _registry
    with open(REGISTRY_PATH, "r", encoding="utf-8") as f:
        _registry = json.load(f)
    log.info("loaded %d device(s) from registry", len(_registry))


def _cleanup_nonce_cache() -> None:
    now = time.time()
    expired = [k for k, seen_at in _seen_nonces.items() if now - seen_at > NONCE_CACHE_TTL_SECONDS]
    for k in expired:
        del _seen_nonces[k]


class ValidateRequest(BaseModel):
    device_id: str
    timestamp: str
    nonce: str
    signature: str


class ValidateResponse(BaseModel):
    valid: bool
    reason: str
    device_id: str


@app.on_event("startup")
def on_startup():
    load_registry()


@app.get("/health")
def health():
    return {"status": "ok", "devices_registered": len(_registry)}


@app.post("/validate", response_model=ValidateResponse)
def validate(req: ValidateRequest):
    _cleanup_nonce_cache()

    # 1. known_device
    device = _registry.get(req.device_id)
    if device is None:
        log.warning("REJECT %s — unknown_device", req.device_id)
        return ValidateResponse(valid=False, reason="unknown_device", device_id=req.device_id)

    if device.get("status") != "active":
        log.warning("REJECT %s — device_not_active", req.device_id)
        return ValidateResponse(valid=False, reason="device_not_active", device_id=req.device_id)

    # 2. fresh_timestamp
    try:
        msg_time = datetime.fromisoformat(req.timestamp.replace("Z", "+00:00"))
    except ValueError:
        log.warning("REJECT %s — malformed_timestamp", req.device_id)
        return ValidateResponse(valid=False, reason="malformed_timestamp", device_id=req.device_id)

    now = datetime.now(timezone.utc)
    drift = abs((now - msg_time).total_seconds())
    if drift > TIMESTAMP_TOLERANCE_SECONDS:
        log.warning("REJECT %s — stale_timestamp (drift=%.1fs)", req.device_id, drift)
        return ValidateResponse(valid=False, reason="stale_timestamp", device_id=req.device_id)

    # 3. nonce_not_reused
    nonce_key = (req.device_id, req.nonce)
    if nonce_key in _seen_nonces:
        log.warning("REJECT %s — replay_detected (nonce reused)", req.device_id)
        return ValidateResponse(valid=False, reason="replay_detected", device_id=req.device_id)

    # 4. valid_signature
    canonical = f"{req.device_id}|{req.timestamp}|{req.nonce}"
    expected_sig = hmac.new(
        device["secret"].encode("utf-8"),
        canonical.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(expected_sig, req.signature):
        log.warning("REJECT %s — invalid_signature", req.device_id)
        return ValidateResponse(valid=False, reason="invalid_signature", device_id=req.device_id)

    _seen_nonces[nonce_key] = time.time()
    log.info("ACCEPT %s", req.device_id)
    return ValidateResponse(valid=True, reason="ok", device_id=req.device_id)
