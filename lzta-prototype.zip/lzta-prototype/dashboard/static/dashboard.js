const REFRESH_MS = 3000;

const COLORS = {
  allow: "#35d68a",
  deny: "#ef5b6b",
  step_up: "#f0b74e",
  green: "#35d68a",
  red: "#ef5b6b",
  amber: "#f0b74e",
  blue: "#5b9bff",
  muted: "#5c6c80",
};

let isPaused = false;
let latestAlertStateByTarget = {};
let latestKnownAlertTimestamp = null;   // for new-alert toast detection
let alertToastInitialized = false;       // avoid toasting historical alerts on first load
let allDecisions = [];                   // cached for client-side filtering
let currentDecisionFilter = "all";

function escapeHtml(s) {
  if (s === null || s === undefined) return "";
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

function fmtTime(iso) {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleTimeString();
  } catch (e) {
    return iso;
  }
}

function updateClock() {
  document.getElementById("clock").textContent = new Date().toLocaleString();
}

async function fetchJson(url) {
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(`${url} -> ${resp.status}`);
  return resp.json();
}

/* ---------- SVG gauge ring (NFR cards) ---------- */

function gaugeSvg(percent, color, size = 60, stroke = 7) {
  const p = Math.max(0, Math.min(100, percent));
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - p / 100);
  const cx = size / 2, cy = size / 2;
  return `
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" class="gauge">
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="${stroke}" />
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${color}" stroke-width="${stroke}"
        stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${offset}"
        transform="rotate(-90 ${cx} ${cy})" style="transition: stroke-dashoffset 0.5s ease" />
    </svg>`;
}

function nfrCard(label, value, pass, verdictText, gaugePercent) {
  const cls = pass === undefined ? "" : (pass ? "pass" : "fail");
  const color = pass === undefined ? COLORS.blue : (pass ? COLORS.green : COLORS.red);
  return `
    <div class="nfr-card ${cls}">
      ${gaugeSvg(gaugePercent, color)}
      <div class="info">
        <div class="label">${escapeHtml(label)}</div>
        <div class="value">${escapeHtml(value)}</div>
        <div class="verdict">${escapeHtml(verdictText)}</div>
      </div>
    </div>`;
}

/* ---------- Status pill ---------- */

function setStatusPill(ok, text) {
  const pill = document.getElementById("status-pill");
  const label = document.getElementById("status-text");
  pill.className = "status-pill " + (ok === null ? "status-unknown" : ok ? "status-ok" : "status-degraded");
  label.textContent = text;
}

/* ---------- Toasts ---------- */

function showToast(html) {
  const container = document.getElementById("toast-container");
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerHTML = html;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 5700);
}

/* ---------- Pause / resume ---------- */

function setupPauseButton() {
  const btn = document.getElementById("pause-btn");
  btn.addEventListener("click", () => {
    isPaused = !isPaused;
    document.getElementById("pause-icon").innerHTML = isPaused ? "&#9654;" : "&#10074;&#10074;";
    document.getElementById("pause-label").textContent = isPaused ? "Resume" : "Pause";
    btn.classList.toggle("active", isPaused);
  });
}

/* ---------- Devices ---------- */

async function refreshDevices() {
  const data = await fetchJson("/api/devices");
  const grid = document.getElementById("devices-grid");
  const hint = document.getElementById("device-count-hint");
  if (!data.devices || data.devices.length === 0) {
    grid.innerHTML = `<div class="empty">${escapeHtml(data.note || "No devices yet")}</div>`;
    hint.textContent = "";
    return;
  }
  hint.textContent = `${data.devices.length} provisioned — click a card for details`;
  grid.innerHTML = data.devices.map(d => {
    const score = d.last_score ?? null;
    const scoreColor = score === null ? "rgba(255,255,255,0.15)" : score >= 70 ? COLORS.green : score >= 40 ? COLORS.amber : COLORS.red;
    const isActive = d.status === "active";
    const decision = d.last_decision || "—";
    return `
      <div class="device-card" data-device-id="${escapeHtml(d.device_id)}">
        <div class="device-card-top">
          <div>
            <div class="device-id">${escapeHtml(d.device_id)}</div>
            <div class="device-type">${escapeHtml(d.device_type)}</div>
          </div>
          <span class="status-dot ${isActive ? "active" : "inactive"}" title="${escapeHtml(d.status)}"></span>
        </div>
        <div class="device-row">
          <span>Last decision</span>
          <span class="badge ${escapeHtml(decision)}">${escapeHtml(decision)}</span>
        </div>
        <div class="device-row">
          <span>Trust score</span>
          <span>${score ?? "—"}</span>
        </div>
        <div class="trust-bar-track">
          <div class="trust-bar-fill" style="width:${score ?? 0}%;background:${scoreColor}"></div>
        </div>
        <div class="device-row" style="margin-top:8px">
          <span>Last seen</span>
          <span>${fmtTime(d.last_seen)}</span>
        </div>
      </div>`;
  }).join("");

  grid.querySelectorAll(".device-card").forEach(card => {
    card.addEventListener("click", () => openDeviceModal(card.dataset.deviceId));
  });
}

/* ---------- Device drill-down modal ---------- */

function sparklineSvg(values, color) {
  if (!values || values.length === 0) {
    return `<div class="empty">No trust-score history yet</div>`;
  }
  const w = 500, h = 60, pad = 4;
  const max = Math.max(100, ...values);
  const min = 0;
  const step = values.length > 1 ? (w - pad * 2) / (values.length - 1) : 0;
  const points = values.map((v, i) => {
    const x = pad + i * step;
    const y = h - pad - ((v - min) / (max - min || 1)) * (h - pad * 2);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  return `
    <svg id="sparkline-svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">
      <polyline points="${points}" fill="none" stroke="${color}" stroke-width="2" />
    </svg>`;
}

async function openDeviceModal(deviceId) {
  const backdrop = document.getElementById("device-modal");
  const body = document.getElementById("modal-body");
  document.getElementById("modal-device-id").textContent = deviceId;
  body.innerHTML = "Loading…";
  backdrop.classList.remove("hidden");

  try {
    const data = await fetchJson(`/api/device/${encodeURIComponent(deviceId)}`);
    if (data.error) {
      body.innerHTML = `<div class="empty">${escapeHtml(data.error)}</div>`;
      return;
    }
    const scores = data.trust_history.map(t => t.score_value);
    const decisionsHtml = data.decisions.length
      ? data.decisions.map(d => `
          <tr>
            <td>${fmtTime(d.decided_at)}</td>
            <td>${escapeHtml(d.mqtt_topic)}</td>
            <td><span class="badge ${escapeHtml(d.decision)}">${escapeHtml(d.decision)}</span></td>
          </tr>`).join("")
      : `<tr><td colspan="3" class="empty">No decisions yet</td></tr>`;

    body.innerHTML = `
      <div class="device-row"><span>Type</span><span>${escapeHtml(data.device.device_type)}</span></div>
      <div class="device-row"><span>Status</span><span>${escapeHtml(data.device.status)}</span></div>
      <div class="device-row"><span>First seen</span><span>${fmtTime(data.device.first_seen)}</span></div>

      <div class="mini-label">Trust score trend (last ${scores.length})</div>
      ${sparklineSvg(scores, COLORS.blue)}

      <div class="mini-label">Recent decisions</div>
      <div class="table-wrap" style="max-height:220px">
        <table>
          <thead><tr><th>Time</th><th>Topic</th><th>Decision</th></tr></thead>
          <tbody>${decisionsHtml}</tbody>
        </table>
      </div>
    `;
  } catch (e) {
    body.innerHTML = `<div class="empty">Failed to load device detail</div>`;
    console.error(e);
  }
}

function setupModal() {
  document.getElementById("modal-close").addEventListener("click", () => {
    document.getElementById("device-modal").classList.add("hidden");
  });
  document.getElementById("device-modal").addEventListener("click", (e) => {
    if (e.target.id === "device-modal") {
      document.getElementById("device-modal").classList.add("hidden");
    }
  });
}

/* ---------- Recent decisions table (with filter/search) ---------- */

function applyDecisionFilters() {
  const searchTerm = document.getElementById("decision-search").value.trim().toLowerCase();
  const tbody = document.querySelector("#decisions-table tbody");

  let rows = allDecisions;
  if (currentDecisionFilter !== "all") {
    rows = rows.filter(d => d.decision === currentDecisionFilter);
  }
  if (searchTerm) {
    rows = rows.filter(d =>
      (d.device_id || "").toLowerCase().includes(searchTerm) ||
      (d.mqtt_topic || "").toLowerCase().includes(searchTerm)
    );
  }

  if (rows.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" class="empty">No matching decisions</td></tr>`;
    return;
  }

  tbody.innerHTML = rows.slice(0, 100).map(d => `
    <tr>
      <td>${fmtTime(d.decided_at)}</td>
      <td>${escapeHtml(d.device_id)}</td>
      <td>${escapeHtml(d.mqtt_topic)}</td>
      <td><span class="badge ${escapeHtml(d.decision)}">${escapeHtml(d.decision)}</span></td>
      <td>${escapeHtml(d.compliance_control_ref || "—")}</td>
    </tr>
  `).join("");
}

function setupDecisionFilters() {
  document.getElementById("decision-search").addEventListener("input", applyDecisionFilters);
  document.querySelectorAll(".filter-pill").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".filter-pill").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      currentDecisionFilter = btn.dataset.filter;
      applyDecisionFilters();
    });
  });
}

async function refreshDecisions() {
  const data = await fetchJson("/api/decisions");
  allDecisions = data.decisions || [];
  applyDecisionFilters();
}

/* ---------- Donut chart (decision breakdown) ---------- */

async function refreshDecisionCounts() {
  const data = await fetchJson("/api/decision_counts");
  const counts = data.counts || {};
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  const hint = document.getElementById("decision-total-hint");
  const svg = document.getElementById("donut-svg");
  const legend = document.getElementById("donut-legend");

  hint.textContent = total ? `${total} total` : "";

  if (total === 0) {
    svg.innerHTML = "";
    legend.innerHTML = `<div class="empty">No decisions yet</div>`;
    return;
  }

  const size = 200, r = 74, stroke = 26, cx = size / 2, cy = size / 2;
  const c = 2 * Math.PI * r;
  let offsetAccum = 0;
  const order = ["allow", "deny", "step_up"];
  const entries = order.filter(k => counts[k]).concat(Object.keys(counts).filter(k => !order.includes(k)));

  let circles = "";
  entries.forEach(decision => {
    const n = counts[decision];
    const frac = n / total;
    const dash = frac * c;
    const color = COLORS[decision] || COLORS.blue;
    circles += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${color}" stroke-width="${stroke}"
      stroke-dasharray="${dash} ${c - dash}" stroke-dashoffset="${-offsetAccum}"
      transform="rotate(-90 ${cx} ${cy})" />`;
    offsetAccum += dash;
  });

  svg.innerHTML = `
    <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="${stroke}" />
    ${circles}
    <text x="${cx}" y="${cy - 4}" text-anchor="middle" fill="#e7edf6" font-size="26" font-weight="800">${total}</text>
    <text x="${cx}" y="${cy + 16}" text-anchor="middle" fill="#8496ab" font-size="11">decisions</text>
  `;

  legend.innerHTML = entries.map(decision => {
    const n = counts[decision];
    const pct = Math.round((n / total) * 100);
    return `
      <div class="legend-row">
        <span class="legend-swatch" style="background:${COLORS[decision] || COLORS.blue}"></span>
        <span>${escapeHtml(decision)}</span>
        <span class="legend-count">${n} (${pct}%)</span>
      </div>`;
  }).join("");
}

/* ---------- Decisions-over-time line chart ---------- */

async function refreshTimeline() {
  const data = await fetchJson("/api/decisions_timeline");
  const buckets = data.buckets || [];
  const svg = document.getElementById("timeline-svg");
  const legend = document.getElementById("timeline-legend");

  if (buckets.length === 0) {
    svg.innerHTML = "";
    return;
  }

  const w = 900, h = 220, padL = 34, padR = 10, padT = 14, padB = 26;
  const plotW = w - padL - padR, plotH = h - padT - padB;
  const maxVal = Math.max(1, ...buckets.flatMap(b => [b.allow, b.deny, b.step_up]));
  const n = buckets.length;
  const xStep = n > 1 ? plotW / (n - 1) : 0;

  function pathFor(series) {
    return buckets.map((b, i) => {
      const x = padL + i * xStep;
      const y = padT + plotH - (b[series] / maxVal) * plotH;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(" ");
  }

  // gridlines + y-axis labels (0, mid, max)
  let grid = "";
  [0, 0.5, 1].forEach(f => {
    const y = padT + plotH - f * plotH;
    grid += `<line x1="${padL}" y1="${y}" x2="${w - padR}" y2="${y}" stroke="rgba(255,255,255,0.06)" />`;
    grid += `<text x="${padL - 6}" y="${y + 3}" text-anchor="end" font-size="9" fill="#5c6c80">${Math.round(f * maxVal)}</text>`;
  });

  // x-axis labels every ~3rd bucket to avoid crowding
  let xLabels = "";
  buckets.forEach((b, i) => {
    if (i % 3 === 0 || i === n - 1) {
      const x = padL + i * xStep;
      xLabels += `<text x="${x}" y="${h - 6}" text-anchor="middle" font-size="9" fill="#5c6c80">${escapeHtml(b.bucket_start)}</text>`;
    }
  });

  svg.innerHTML = `
    ${grid}
    <path d="${pathFor("allow")}" fill="none" stroke="${COLORS.allow}" stroke-width="2.2" />
    <path d="${pathFor("deny")}" fill="none" stroke="${COLORS.deny}" stroke-width="2.2" />
    <path d="${pathFor("step_up")}" fill="none" stroke="${COLORS.step_up}" stroke-width="2.2" />
    ${xLabels}
  `;

  legend.innerHTML = ["allow", "deny", "step_up"].map(k => `
    <div class="legend-row">
      <span class="legend-swatch" style="background:${COLORS[k]}"></span>
      <span>${escapeHtml(k)}</span>
    </div>`).join("");
}

/* ---------- Alerts (+ toast on new alert, + state for topology/status) ---------- */

async function refreshAlerts() {
  const data = await fetchJson("/api/alerts");
  const container = document.getElementById("alerts-list");

  if (!data.alerts || data.alerts.length === 0) {
    container.innerHTML = `<div class="empty">${escapeHtml(data.note || "No alerts recorded")}</div>`;
    latestAlertStateByTarget = {};
    alertToastInitialized = true;
    return;
  }

  const seen = new Set();
  const state = {};
  for (const a of data.alerts) {
    if (a.event === "alert_raised" || a.event === "alert_resolved") {
      if (!seen.has(a.target)) {
        seen.add(a.target);
        state[a.target] = a.event === "alert_raised";
      }
    }
  }
  latestAlertStateByTarget = state;

  const raisedEvents = data.alerts.filter(a => a.event === "alert_raised");
  if (raisedEvents.length > 0) {
    const newest = raisedEvents[0]; // data.alerts is newest-first
    if (!alertToastInitialized) {
      // First load: remember the newest existing alert without toasting it —
      // we only want to toast alerts that happen WHILE someone is watching.
      latestKnownAlertTimestamp = newest.at;
      alertToastInitialized = true;
    } else if (newest.at !== latestKnownAlertTimestamp) {
      latestKnownAlertTimestamp = newest.at;
      showToast(`<strong>ALERT</strong><br>${escapeHtml(newest.target)} dropped to ${newest.uptime_percent}% (threshold ${newest.threshold_percent}%)`);
    }
  } else {
    alertToastInitialized = true;
  }

  const rows = data.alerts.filter(a => a.event === "alert_raised" || a.event === "alert_resolved").slice(0, 12);
  if (rows.length === 0) {
    container.innerHTML = `<div class="empty">No alert events yet (monitor running, all healthy)</div>`;
    return;
  }

  container.innerHTML = rows.map(a => {
    if (a.event === "alert_raised") {
      return `
        <div class="alert-row alert-raised">
          <span class="alert-icon">!</span>
          <span><strong>${escapeHtml(a.target)}</strong> dropped to ${a.uptime_percent}% (threshold ${a.threshold_percent}%)</span>
          <span class="alert-time">${fmtTime(a.at)}</span>
        </div>`;
    }
    return `
      <div class="alert-row alert-resolved">
        <span class="alert-icon">&#10003;</span>
        <span><strong>${escapeHtml(a.target)}</strong> recovered — back to ${a.uptime_percent}%</span>
        <span class="alert-time">${fmtTime(a.at)}</span>
      </div>`;
  }).join("");
}

/* ---------- System topology diagram ---------- */

const TOPOLOGY_NODES = [
  { id: "device-glucose", label: "Glucose", sub: "device", x: 90, y: 40 },
  { id: "device-pulseox", label: "Pulse Ox", sub: "device", x: 90, y: 110 },
  { id: "device-heartrate", label: "Heart Rate", sub: "device", x: 90, y: 180 },
  { id: "gateway-broker-tcp", label: "Gateway Broker", sub: "device_net", x: 300, y: 110, alertTarget: "gateway-broker-tcp" },
  { id: "gateway", label: "Gateway", sub: "PEP + Local PDP", x: 500, y: 110, alertTarget: null },
  { id: "auth-service", label: "Auth Service", sub: "gateway_net", x: 690, y: 45, alertTarget: "auth-service" },
  { id: "trust-engine", label: "Trust Engine", sub: "gateway_net", x: 690, y: 175, alertTarget: "trust-engine" },
  { id: "core-broker-tcp", label: "Core Broker", sub: "broker_net", x: 850, y: 110, alertTarget: "core-broker-tcp" },
];

const TOPOLOGY_EDGES = [
  ["device-glucose", "gateway-broker-tcp"], ["device-pulseox", "gateway-broker-tcp"], ["device-heartrate", "gateway-broker-tcp"],
  ["gateway-broker-tcp", "gateway"],
  ["gateway", "auth-service"], ["gateway", "trust-engine"],
  ["gateway", "core-broker-tcp"],
];

function nodeById(id) { return TOPOLOGY_NODES.find(n => n.id === id); }

function renderTopology() {
  const svg = document.getElementById("topology-svg");

  const edges = TOPOLOGY_EDGES.map(([a, b]) => {
    const na = nodeById(a), nb = nodeById(b);
    return `<line class="topo-edge" x1="${na.x}" y1="${na.y}" x2="${nb.x}" y2="${nb.y}" />`;
  }).join("");

  const nodes = TOPOLOGY_NODES.map(n => {
    let color = COLORS.blue;   // default: not monitored (e.g. gateway itself, devices)
    if (n.alertTarget) {
      const breaching = latestAlertStateByTarget[n.alertTarget];
      color = breaching === undefined ? COLORS.muted : (breaching ? COLORS.red : COLORS.green);
    }
    const pulse = n.alertTarget && latestAlertStateByTarget[n.alertTarget] ? "topo-pulse" : "";
    return `
      <g>
        <circle cx="${n.x}" cy="${n.y}" r="20" fill="${color}" fill-opacity="0.18" stroke="${color}" stroke-width="2" class="${pulse}" />
        <circle cx="${n.x}" cy="${n.y}" r="5" fill="${color}" />
        <text x="${n.x}" y="${n.y + 38}" text-anchor="middle" class="topo-node-label">${escapeHtml(n.label)}</text>
        <text x="${n.x}" y="${n.y + 51}" text-anchor="middle" class="topo-sub-label">${escapeHtml(n.sub)}</text>
      </g>`;
  }).join("");

  svg.innerHTML = edges + nodes;
}

/* ---------- Compliance panel ---------- */

async function refreshCompliance() {
  const data = await fetchJson("/api/compliance");
  const container = document.getElementById("compliance-list");
  if (!data.controls || data.controls.length === 0) {
    container.innerHTML = `<div class="empty">${escapeHtml(data.note || "No compliance-tagged events yet")}</div>`;
    return;
  }
  container.innerHTML = data.controls.map(c => `
    <div class="compliance-row">
      <div class="ref-name">${escapeHtml(c.ref)}</div>
      <div class="ref-counts">
        <span>${c.total} total</span>
        <span class="allowed">${c.allowed} allowed</span>
        <span class="denied">${c.denied} denied</span>
      </div>
    </div>`).join("");
}

/* ---------- Recommendations panel ---------- */

async function refreshRecommendations() {
  const data = await fetchJson("/api/recommendations");
  const container = document.getElementById("recommendations-list");

  if (data.healthy || !data.recommendations || data.recommendations.length === 0) {
    container.innerHTML = `<div class="recommendation-row healthy">All monitored services are within their availability threshold. No action needed.</div>`;
    return;
  }

  container.innerHTML = data.recommendations.map(r => `
    <div class="recommendation-row">
      <strong>${escapeHtml(r.target)}</strong> — ${escapeHtml(r.recommendation)}
    </div>`).join("");
}

/* ---------- NFR cards + overall status pill ---------- */

async function refreshNfr() {
  const data = await fetchJson("/api/nfr_status");
  const container = document.getElementById("nfr-cards");

  if (!data.available) {
    container.innerHTML = `<div class="empty">${escapeHtml(data.note || "No metrics yet — run scripts/summarize_metrics.py")}</div>`;
    return;
  }

  let cards = "";
  let anyFail = false;

  if (data.nfr1) {
    anyFail = anyFail || !data.nfr1.pass;
    const gaugePct = Math.min(100, (data.nfr1.p95_ms / data.nfr1.target_ms) * 100);
    cards += nfrCard("NFR1 — Auth Latency (p95)", `${data.nfr1.p95_ms} ms`, data.nfr1.pass,
      data.nfr1.pass ? `within ${data.nfr1.target_ms}ms target` : `over ${data.nfr1.target_ms}ms target`, gaugePct);
  }
  if (data.nfr2) {
    anyFail = anyFail || !data.nfr2.pass;
    const gaugePct = Math.min(100, (data.nfr2.max_avg_cpu_percent / data.nfr2.target_percent) * 100);
    cards += nfrCard("NFR2 — Peak Avg CPU", `${data.nfr2.max_avg_cpu_percent}%`, data.nfr2.pass,
      data.nfr2.pass ? `within ${data.nfr2.target_percent}% target` : `over ${data.nfr2.target_percent}% target`, gaugePct);
  }
  if (data.nfr3) {
    anyFail = anyFail || !data.nfr3.pass;
    const worst = Math.min(...Object.values(data.nfr3.targets));
    cards += nfrCard("NFR3 — Worst Availability", `${worst}%`, data.nfr3.pass,
      data.nfr3.pass ? `meets ${data.nfr3.target_percent}% target` : `below ${data.nfr3.target_percent}% target`, worst);
  }

  container.innerHTML = cards || `<div class="empty">No NFR data in summary.json</div>`;

  const anyActiveAlert = Object.values(latestAlertStateByTarget).some(breaching => breaching);
  if (!data.nfr1 && !data.nfr2 && !data.nfr3 && !anyActiveAlert) {
    setStatusPill(null, "Awaiting data");
  } else if (anyFail || anyActiveAlert) {
    setStatusPill(false, "Degraded");
  } else {
    setStatusPill(true, "All Systems Operational");
  }
}

/* ---------- Orchestration ---------- */

async function refreshAll() {
  updateClock();
  if (isPaused) return;

  // alerts first — several other panels depend on latestAlertStateByTarget
  await refreshAlerts().catch(console.error);
  renderTopology();

  const tasks = [
    refreshDevices(), refreshDecisions(), refreshDecisionCounts(),
    refreshTimeline(), refreshNfr(), refreshCompliance(), refreshRecommendations(),
  ];
  const results = await Promise.allSettled(tasks);
  results.forEach(r => { if (r.status === "rejected") console.error(r.reason); });
}

setupPauseButton();
setupModal();
setupDecisionFilters();
setInterval(updateClock, 1000);
refreshAll();
setInterval(refreshAll, REFRESH_MS);
