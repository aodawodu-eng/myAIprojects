"""
app.py — LZTA Monitoring Dashboard

A live, browser-based view into the running system, built specifically
to be demo-friendly for a defence: device status, recent access
decisions, active alerts, and NFR compliance, refreshing automatically.

Deliberately READ-ONLY and file-based — this dashboard never talks to
auth-service, trust-engine, or either broker over the network. It only
reads logs/audit.db, logs/alerts.log, logs/policy_cache.json, and
metrics/summary.json, all mounted read-only. This is itself a small
demonstration of the project's own least-privilege principle: a
monitoring tool has no business holding write access or a network path
to the services it's observing.

Routes:
    GET /                     -> dashboard HTML page
    GET /api/devices          -> device list with last-seen decision/score
    GET /api/decisions        -> recent access decisions (paginated)
    GET /api/decision_counts  -> allow/deny/step_up totals, for the chart
    GET /api/decisions_timeline -> allow/deny/step_up counts bucketed into
                                    the last 10 one-minute windows
    GET /api/device/<id>      -> single device detail: metadata, recent
                                    decisions, trust-score history
    GET /api/compliance       -> audit_log grouped by compliance control
                                    reference, with allow/deny counts
    GET /api/recommendations  -> plain-English guidance derived from any
                                    currently-active alert
    GET /api/alerts           -> recent alert_monitor.py events
    GET /api/nfr_status       -> latest NFR1/2/3 verdicts, if summary.json exists
    GET /api/health           -> dashboard's own health check
"""

import json
import sqlite3
import time
from pathlib import Path

from flask import Flask, jsonify, render_template

APP_ROOT = Path(__file__).resolve().parent
DB_PATH = Path("/app/logs/audit.db")
ALERTS_PATH = Path("/app/logs/alerts.log")
POLICY_CACHE_PATH = Path("/app/logs/policy_cache.json")
SUMMARY_PATH = Path("/app/metrics/summary.json")

app = Flask(__name__)


def get_db_connection(retries: int = 3, delay: float = 0.1):
    """SQLite can raise 'database is locked' if this read happens to
    overlap a write from the gateway. A short retry loop is enough for a
    read-only dashboard polling every few seconds — a real production
    dashboard at higher write concurrency would use WAL mode on the
    writer side instead, but that's the gateway's concern, not this
    read-only viewer's."""
    last_exc = None
    for attempt in range(retries):
        try:
            conn = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True, timeout=2)
            conn.row_factory = sqlite3.Row
            return conn
        except sqlite3.OperationalError as exc:
            last_exc = exc
            time.sleep(delay)
    raise last_exc


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "db_exists": DB_PATH.exists()})


@app.route("/api/devices")
def devices():
    if not DB_PATH.exists():
        return jsonify({"devices": [], "note": "audit.db not found yet — has the gateway processed any messages?"})

    conn = get_db_connection()
    try:
        rows = conn.execute("""
            SELECT
                d.device_id,
                d.device_type,
                d.status,
                d.first_seen,
                (SELECT ad.decision FROM access_decisions ad
                 JOIN sessions s ON ad.session_id = s.session_id
                 WHERE s.device_id = d.device_id
                 ORDER BY ad.decision_id DESC LIMIT 1) AS last_decision,
                (SELECT ts.score_value FROM trust_scores ts
                 WHERE ts.device_id = d.device_id
                 ORDER BY ts.score_id DESC LIMIT 1) AS last_score,
                (SELECT s.token_issued_at FROM sessions s
                 WHERE s.device_id = d.device_id
                 ORDER BY s.token_issued_at DESC LIMIT 1) AS last_seen
            FROM devices d
            ORDER BY d.device_id
        """).fetchall()
        return jsonify({"devices": [dict(r) for r in rows]})
    finally:
        conn.close()


@app.route("/api/decisions")
def decisions():
    if not DB_PATH.exists():
        return jsonify({"decisions": []})

    conn = get_db_connection()
    try:
        rows = conn.execute("""
            SELECT
                ad.decision_id,
                ad.decided_at,
                ad.mqtt_topic,
                ad.decision,
                s.device_id,
                al.compliance_control_ref
            FROM access_decisions ad
            JOIN sessions s ON ad.session_id = s.session_id
            LEFT JOIN audit_log al ON al.decision_id = ad.decision_id
            ORDER BY ad.decision_id DESC
            LIMIT 100
        """).fetchall()
        return jsonify({"decisions": [dict(r) for r in rows]})
    finally:
        conn.close()


@app.route("/api/decision_counts")
def decision_counts():
    if not DB_PATH.exists():
        return jsonify({"counts": {}})

    conn = get_db_connection()
    try:
        rows = conn.execute("""
            SELECT decision, COUNT(*) as n FROM access_decisions GROUP BY decision
        """).fetchall()
        return jsonify({"counts": {r["decision"]: r["n"] for r in rows}})
    finally:
        conn.close()


@app.route("/api/alerts")
def alerts():
    if not ALERTS_PATH.exists():
        return jsonify({"alerts": [], "note": "no alerts.log yet — run scripts/alert_monitor.py"})

    lines = ALERTS_PATH.read_text(encoding="utf-8").strip().splitlines()
    events = []
    for line in lines[-50:]:
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    events.reverse()  # newest first
    return jsonify({"alerts": events})


@app.route("/api/nfr_status")
def nfr_status():
    if not SUMMARY_PATH.exists():
        return jsonify({"available": False, "note": "run scripts/summarize_metrics.py first"})

    try:
        summary = json.loads(SUMMARY_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return jsonify({"available": False, "note": "metrics/summary.json is malformed"})

    auth = summary.get("latency", {}).get("auth_latency_ms", {})
    availability = summary.get("availability", {})
    containers = summary.get("containers", {})

    result = {"available": True}

    if auth.get("count"):
        result["nfr1"] = {"p95_ms": auth["p95"], "target_ms": 100, "pass": auth["p95"] < 100}

    if isinstance(containers, dict) and "note" not in containers:
        cpu_avgs = [c["cpu_percent"]["avg"] for c in containers.values() if c.get("cpu_percent", {}).get("count")]
        if cpu_avgs:
            worst = max(cpu_avgs)
            result["nfr2"] = {"max_avg_cpu_percent": round(worst, 2), "target_percent": 15, "pass": worst < 15}

    if isinstance(availability, dict) and "note" not in availability:
        result["nfr3"] = {
            "targets": {k: v["uptime_percent"] for k, v in availability.items()},
            "target_percent": 99.9,
            "pass": all(v["uptime_percent"] >= 99.9 for v in availability.values()),
        }

    return jsonify(result)


# ---------------------------------------------------------------------------
# Decisions-over-time timeline (for the live line chart)
# ---------------------------------------------------------------------------

@app.route("/api/decisions_timeline")
def decisions_timeline():
    if not DB_PATH.exists():
        return jsonify({"buckets": []})

    from datetime import datetime, timedelta, timezone as tz

    minutes = 10
    now = datetime.now(tz.utc)
    since = now - timedelta(minutes=minutes)

    conn = get_db_connection()
    try:
        rows = conn.execute(
            "SELECT decided_at, decision FROM access_decisions WHERE decided_at >= ? ORDER BY decided_at ASC",
            (since.isoformat(),),
        ).fetchall()
    finally:
        conn.close()

    # Build `minutes` contiguous 1-minute buckets, oldest first, so the
    # chart always shows a continuous timeline even if some minutes had
    # zero traffic (which itself is informative during a fault demo).
    buckets = []
    for i in range(minutes):
        bucket_start = since + timedelta(minutes=i)
        buckets.append({
            "bucket_start": bucket_start.strftime("%H:%M"),
            "allow": 0, "deny": 0, "step_up": 0,
        })

    for row in rows:
        try:
            ts = datetime.fromisoformat(row["decided_at"].replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            continue
        idx = int((ts - since).total_seconds() // 60)
        if 0 <= idx < minutes:
            decision = row["decision"]
            if decision in ("allow", "deny", "step_up"):
                buckets[idx][decision] += 1

    return jsonify({"buckets": buckets})


# ---------------------------------------------------------------------------
# Device drill-down
# ---------------------------------------------------------------------------

@app.route("/api/device/<device_id>")
def device_detail(device_id):
    if not DB_PATH.exists():
        return jsonify({"error": "audit.db not found"}), 404

    conn = get_db_connection()
    try:
        device = conn.execute(
            "SELECT * FROM devices WHERE device_id = ?", (device_id,)
        ).fetchone()
        if device is None:
            return jsonify({"error": "unknown device"}), 404

        decisions = conn.execute("""
            SELECT ad.decided_at, ad.mqtt_topic, ad.decision, al.compliance_control_ref
            FROM access_decisions ad
            JOIN sessions s ON ad.session_id = s.session_id
            LEFT JOIN audit_log al ON al.decision_id = ad.decision_id
            WHERE s.device_id = ?
            ORDER BY ad.decision_id DESC LIMIT 20
        """, (device_id,)).fetchall()

        scores = conn.execute("""
            SELECT score_value, computed_at FROM trust_scores
            WHERE device_id = ? ORDER BY score_id DESC LIMIT 20
        """, (device_id,)).fetchall()

        return jsonify({
            "device": dict(device),
            "decisions": [dict(r) for r in decisions],
            "trust_history": [dict(r) for r in reversed(scores)],  # oldest first, for a left-to-right sparkline
        })
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Compliance summary
# ---------------------------------------------------------------------------

@app.route("/api/compliance")
def compliance():
    if not DB_PATH.exists():
        return jsonify({"controls": [], "note": "audit.db not found yet"})

    conn = get_db_connection()
    try:
        rows = conn.execute("""
            SELECT al.compliance_control_ref AS ref,
                   COUNT(*) AS total,
                   SUM(CASE WHEN ad.decision = 'deny' THEN 1 ELSE 0 END) AS denied,
                   SUM(CASE WHEN ad.decision != 'deny' THEN 1 ELSE 0 END) AS allowed
            FROM audit_log al
            JOIN access_decisions ad ON al.decision_id = ad.decision_id
            WHERE al.compliance_control_ref IS NOT NULL
            GROUP BY al.compliance_control_ref
            ORDER BY total DESC
        """).fetchall()
        return jsonify({"controls": [dict(r) for r in rows]})
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Recommendations — plain-English guidance derived from current alert
# state. Rule-based, not a diagnosis: maps a currently-breaching target to
# a short, specific next step referencing the project's own scripts,
# mirroring docs/DEFENCE_DEMO.md's troubleshooting table. Falls back to a
# generic message for any target not explicitly covered.
# ---------------------------------------------------------------------------

_RECOMMENDATIONS = {
    "trust-engine": "trust-engine is unreachable. Check for a leftover fault-injection rule "
                     "(./scripts/inject_fault.sh status trust-engine) before assuming a real "
                     "outage, then check container health (docker compose logs trust-engine).",
    "auth-service": "auth-service is unreachable. Check for a leftover fault-injection rule "
                     "(./scripts/inject_fault.sh status auth-service), then check container "
                     "health (docker compose logs auth-service).",
    "gateway-broker-tcp": "The gateway-facing broker is unreachable — devices cannot connect "
                     "at all. Check docker compose logs gateway-broker and confirm the "
                     "container is Up.",
    "core-broker-tcp": "The upstream broker is unreachable — allowed messages cannot be "
                     "forwarded. Check docker compose logs core-broker.",
}
_GENERIC_RECOMMENDATION = "{target} is unreachable. Check docker compose ps and docker compose logs {target}."


@app.route("/api/recommendations")
def recommendations():
    if not ALERTS_PATH.exists():
        return jsonify({"recommendations": [], "note": "no alerts.log yet"})

    lines = ALERTS_PATH.read_text(encoding="utf-8").strip().splitlines()
    events = []
    for line in lines:
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue

    # Derive currently-breaching targets: for each target, look at its
    # most recent raised/resolved event only.
    latest_by_target = {}
    for e in events:
        if e.get("event") in ("alert_raised", "alert_resolved"):
            latest_by_target[e["target"]] = e  # later events overwrite earlier ones, log is append-only in order

    breaching_targets = [t for t, e in latest_by_target.items() if e["event"] == "alert_raised"]

    if not breaching_targets:
        return jsonify({"recommendations": [], "healthy": True})

    recs = []
    for target in breaching_targets:
        text = _RECOMMENDATIONS.get(target, _GENERIC_RECOMMENDATION.format(target=target))
        recs.append({"target": target, "recommendation": text})

    return jsonify({"recommendations": recs, "healthy": False})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
